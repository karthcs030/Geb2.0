package com.tfs
/*
 * Copyright (c) 2018. https://automationschool.com
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

class ConfigReader {

	def static environ = "notset"

	static ConfigObject getConfiguration() {
		def env = System.getProperty("geb.profile")

		if(env) {
			environ = env
		}

		def config = new ConfigSlurper(environ).parse(new File('src//test//resources//SearchUrlConfig.groovy').toURI().toURL())
		def loginFlowConfig = new ConfigSlurper(environ).parse(new File('src//test//resources//LoginFlowConfig.groovy').toURI().toURL())
		config.loginFlowConfig = loginFlowConfig
		def dbConfig = new ConfigSlurper(environ).parse(new File('C://code//DBConfig.groovy').toURI().toURL())
		config.dbConfig = dbConfig
		config

	}

	static ConfigObject getUserData(String country){
		def getData = new ConfigSlurper(country).parse(new File('src//test//resources//UserData.groovy').toURI().toURL())
		getData
	}
}