package com.tfs.common

import geb.spock.GebReportingSpec


class BaseGebSpec extends GebReportingSpec {

}