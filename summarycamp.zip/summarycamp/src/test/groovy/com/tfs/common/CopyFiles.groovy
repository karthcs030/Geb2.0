package com.tfs.common

import com.tfs.ConfigReader
import com.tfs.pages.UrlFormatter
import geb.spock.GebReportingSpec
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class CopyFiles extends GebReportingSpec {
    static ConfigObject dbConfig
    static ConfigObject config

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg;
        UrlFormatter.config = cfg;
        dbConfig = config.dbConfig
        //def browser = new Browser(driver)
    }
    String filepath=System.getProperty("user.dir")+"\\build\\"

    Logger log = LoggerFactory.getLogger(CopyFiles.class)

    @Step("Modify PO number in to one year old PO Number")
    def "Fetch Total Order count"() {

       // CartPage cart = new CartPage(browser)

        //cart.copyFiles()


        where:
        dburl | dbport | intance  | user | password | query
        dbConfig.dburl   | dbConfig.port| dbConfig.instance | dbConfig.dbUser | dbConfig.dbPassword | dbConfig.Total_order_count_query


    }



}
