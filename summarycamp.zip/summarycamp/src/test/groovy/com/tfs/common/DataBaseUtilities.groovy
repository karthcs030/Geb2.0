package com.tfs.common

import com.opencsv.CSVWriter
import groovy.sql.Sql
import oracle.jdbc.pool.OracleDataSource
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.Statement
import java.text.DateFormat
import java.text.SimpleDateFormat


class DataBaseUtilities {
    Logger log = LoggerFactory.getLogger(DataBaseUtilities.class)

    /* Following method will help to Open connection with Database*/

   Connection openDBConnection(String url, String port, String instance, String dbUser, String dbPassword) {
        try {
            def dbUrl = "jdbc:postgresql://" + url + ":" + port +"/"+ instance

            def dbDriver = "org.postgresql.Driver"

            def sql = Sql.newInstance(dbUrl, dbUser, dbPassword, dbDriver)

            log.info("Opened new Prod Postgress DB connection")

            return sql.getConnection()

        } catch (Exception e) {
            e.printStackTrace()

        }
    }

    Connection openOracleDBConnection(String url, String port, String dbUser, String dbPassword) {
        try {
            Connection connection = null;
            /*OracleDataSource dataSource = new OracleDataSource();
            dataSource.setServerName(url);
            dataSource.setPortNumber(1521);
            dataSource.setDriverType("thin");
            dataSource.setUser(dbUser);
            dataSource.setPassword(dbPassword);
            dataSource.setDatabaseName(instance);
            return dataSource.getConnection();*/

            //def dbDriver = "com.sap.db.jdbc.Driver"

           // def sql = Sql.newInstance(url, port, dbUser, dbPassword, dbDriver)
            connection = DriverManager.getConnection(
                    "jdbc:sap://10.10.1.17:32415/?autocommit=false", "ZP_EZRX2",
                    "ZPeZRx2!");

            log.info("Opened new SAP Hana database connection")

            return connection

        } catch (Exception e) {
            e.printStackTrace()

        }
    }



    //Following method will help to execute query in Database
    ResultSet executeDBQuery(Connection connection, String queryString, String filename){
        try {
            Statement statement = connection.createStatement()
          //  println("updated query"+queryString)

           // ResultSet resultSet = statement.executeQuery(queryString)


            ResultSet myResultSet = statement.executeQuery(queryString)

           // log.info("Executed query: " + queryString)
//            log.info(myResultSet)
            /*while (myResultSet.next())
            {
                String result_param = myResultSet.getString(1)
                log.info(result_param)
                return myResultSet

            } */

            CSVWriter writer = new CSVWriter(new FileWriter(filename, false),
                    CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END);


            Boolean includeHeaders = true;


               writer.writeAll(myResultSet, includeHeaders);


            writer.flush();
            writer.close();
            return myResultSet
        } catch (Exception e) {
            e.printStackTrace()
        }
    }

    ResultSet executeDBQueryCMGT(Connection connection, String queryString, String filename){
        try {
            Statement statement = connection.createStatement()
            //  println("updated query"+queryString)

            // ResultSet resultSet = statement.executeQuery(queryString)


            java.sql.ResultSet myResultSet = statement.executeQuery(queryString)

            // log.info("Executed query: " + queryString)
//            log.info(myResultSet)
            if(myResultSet.next())
            {
                String result_param = myResultSet.getString(1)
                log.info(result_param)
                CSVWriter writer = new CSVWriter(new FileWriter(filename, false),
                        CSVWriter.DEFAULT_SEPARATOR,
                        CSVWriter.NO_QUOTE_CHARACTER,
                        CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                        CSVWriter.DEFAULT_LINE_END);


                Boolean includeHeaders = true;


                writer.writeAll(myResultSet, includeHeaders);

                writer.flush();
                writer.close();
                return myResultSet
               // return myResultSet

            }

           /* CSVWriter writer = new CSVWriter(new FileWriter(filename, false),
                    CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END);


            Boolean includeHeaders = true;


            writer.writeAll(myResultSet, includeHeaders);


            writer.close();
            return myResultSet*/
        } catch (Exception e) {
            e.printStackTrace()
        }
    }

    // Following method will help to execute update query in Database
    void executeDBUpdate(Connection connection, String queryString) {
        try {
            Statement statement = connection.createStatement()

            statement.executeUpdate(queryString)

            log.info("Executed update query: " + queryString)

        } catch (Exception e) {
            e.printStackTrace()

        }

    }




    //Following method will help to close database connection
//    closeDBConnection(Connection connection) {
//        try {
//            connection.close()
//
//            log.info("Closed database connection")
//        } catch (Exception e) {
//            e.printStackTrace()
//
//        }
//
//    }
    def executePostgressquery(Connection connection, String queryString, String paramter) {
        try {
            String enddate;
            String enddatetime;
            Statement statement = connection.createStatement()
            ResultSet myResultSet = statement.executeQuery(queryString)
            while(myResultSet.next())
            {
                enddate=myResultSet.getString("end_date");
              enddatetime=myResultSet.getString("end_datetime");
            }
            myResultSet.close();
            statement.close();
           // connection.close();

            return  Arrays.asList(enddate,enddatetime)

        } catch (Exception e) {
            e.printStackTrace()
        }

    }


    def executeSAP(Connection connection, String queryString, String paramter) {
        try {

            String queryvalue;
            Statement statement = connection.createStatement()
            ResultSet myResultSet = statement.executeQuery(queryString)
            while(myResultSet.next())
            {
                queryvalue=myResultSet.getString(paramter);

            }
            myResultSet.close();
            statement.close();


            return queryvalue.toString()

        } catch (Exception e) {
            e.printStackTrace()
        }

    }

    def String getCurrentDate(){
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String uniqeUserId = df.format(date);
        System.out.println(uniqeUserId);
        return uniqeUserId;
    }
}
