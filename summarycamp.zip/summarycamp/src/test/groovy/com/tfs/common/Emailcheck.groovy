package com.tfs.common

import com.tfs.ConfigReader
import com.tfs.common.DataBaseUtilities
import com.tfs.pages.Email
import com.tfs.pages.*

import com.tfs.pages.UrlFormatter
import geb.spock.GebReportingSpec
import io.qameta.allure.Step
import microsoft.exchange.webservices.data.core.ExchangeService
import microsoft.exchange.webservices.data.property.complex.ItemId
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore

class Emailcheck extends GebReportingSpec {
    static ConfigObject dbConfig
    static ConfigObject config
    //

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg;
        UrlFormatter.config = cfg;
        dbConfig = config.dbConfig
        //def browser = new Browser(driver)
    }
    String filepath=System.getProperty("user.dir")+"\\build\\"

    Logger log = LoggerFactory.getLogger(Emailcheck.class)
    @Ignore
    @Step("Modify PO number in to one year old PO Number")
    def "Check email connection"() {
        TestmyInbox xchangevar = new TestmyInbox()
        ExchangeService connectedobject = xchangevar.createConnection()
       // xchangevar.read(connectedobject)

        where:
        dburl | dbport | intance  | user | password | query
        dbConfig.dburl   | dbConfig.port| dbConfig.instance | dbConfig.dbUser | dbConfig.dbPassword | dbConfig.Total_order_count_query


    }

    @Step("Modify PO number in to one year old PO Number")
    def "Check email Exchange connection"() {
        MSMailService xchangevar = new MSMailService()
        ExchangeService connectedobject = xchangevar.createConnection()
        xchangevar.readAttachmentEmail(connectedobject)
        // xchangevar.read(connectedobject)

        where:
        dburl | dbport | intance  | user | password | query
        dbConfig.dburl   | dbConfig.port| dbConfig.instance | dbConfig.dbUser | dbConfig.dbPassword | dbConfig.Total_order_count_query


    }



}
