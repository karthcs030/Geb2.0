package com.tfs.common

import org.testng.ITestContext
import org.testng.ITestListener
import org.testng.ITestResult

class ExtentReportListener implements ITestListener {


    @Override
    void onTestStart(ITestResult result) {


    }

    @Override
    void onTestSuccess(ITestResult result) {

    }

    @Override
    void onTestFailure(ITestResult result) {

    }

    @Override
    void onTestSkipped(ITestResult result) {

    }

    @Override
    void onTestFailedButWithinSuccessPercentage(ITestResult result) {

    }

    @Override
    void onStart(ITestContext context) {

    }

    @Override
    void onFinish(ITestContext context) {

    }
}
