package com.tfs.common

import com.tfs.ConfigReader
import geb.Browser
import io.qameta.allure.Step
import org.openqa.selenium.Cookie
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class Invoke extends webDriverLibrary {
    Logger log = LoggerFactory.getLogger(com.tfs.pages.HomePage.class)
    ConfigObject config = ConfigReader.getConfiguration()

    static Browser browser

    Invoke(Browser browser){
        this.browser=browser
    }

    @Step("Changing cookies to country{0}, Language to {1}")
    def browseUrl(String country, String language) {
        //Browser browser = new Browser()
        browser.driver.get(config.home)

        browser.driver.manage().deleteCookieNamed("CK_ISO_CODE")
        browser.driver.manage().deleteCookieNamed("CK_LANG_CODE")
        browser.driver.manage().deleteAllCookies()

        browser.driver.manage().addCookie(new Cookie("CK_ISO_CODE", country))
        browser.driver.manage().addCookie(new Cookie("CK_LANG_CODE", language))


        browser.driver.navigate().refresh()
        Thread.sleep(5000)

        log.info("Navigated to TF for country code " + country + " and Lang: " + language)

        //return new LoginPage(browser)

    }




}
