package com.tfs.common

public class configdataFetcher {
 
 private static Properties properties;
 private final static String propertyFilePath=System.getProperty("user.dir")+"\\src\\test\\groovy\\com\\tfs\\common\\config.properties";
 
 
 public static String configData(String locator){
 BufferedReader reader;
 try {
 reader = new BufferedReader(new FileReader(propertyFilePath));
 properties = new Properties();
 try {
 properties.load(reader);
 reader.close();
 } catch (IOException e) {
 e.printStackTrace();
 }
 } catch (FileNotFoundException e) {
 e.printStackTrace();
 throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
  } 
 String result = properties.getProperty(locator);
 return result;
 
 }
}
