package com.tfs.common

import com.tfs.ConfigReader
import com.tfs.pages.UrlFormatter
import geb.spock.GebReportingSpec
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore

import java.text.SimpleDateFormat

class csmValidations extends GebReportingSpec {
    static ConfigObject dbConfig
    static ConfigObject config
    String resultset
    String Proda;
    String Prodb
    String csm;
    String twProd;
    String twCSM;

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg;
        UrlFormatter.config = cfg;
        dbConfig = config.dbConfig
        //def browser = new Browser(driver)
    }
    String filepath=System.getProperty("user.dir")+"\\build\\"
    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
    Date date = new Date();
    String datestring = formatter.format(date)

    Logger log = LoggerFactory.getLogger(csmValidations.class)


    def "Verify if ETL activity is completed and current date is present"() {

        given: DataBaseUtilities dataBaseUtilities = new DataBaseUtilities()

        when:


        def connection = dataBaseUtilities.openDBConnection(dburl.toString(), dbport.toString(), intance.toString(), user.toString(), password.toString())

       // def rs = dataBaseUtilities.executeDBQuery(connection, query.toString(), filepath+"SKUORDERS"+"_"+datestring+".csv")
        def rs = dataBaseUtilities.executePostgressquery(connection, query.toString(), "end_date")

        println("ETL Enddate"+rs.get(0).toString())
        println("ETL Endtime"+rs.get(1).toString())


        then: "verify validations"
      //  rs.get(0).contentEquals(dataBaseUtilities.getCurrentDate())
      //  rs.get(0).contains(dataBaseUtilities.getCurrentDate())
      //  csm == Proda
       // twProd == twCSM


        where:
        dburl | dbport | intance  | user | password | query
        dbConfig.dburl   | dbConfig.dbport | dbConfig.instance | dbConfig.dbusername | dbConfig.dbpassword | dbConfig.selectall


    }

    def "Verify CSM records in Postgress and SAP hana DB"() {

        given: DataBaseUtilities dataBaseUtilities = new DataBaseUtilities()

        when:


        def connection = dataBaseUtilities.openDBConnection(dburl.toString(), dbport.toString(), intance.toString(), user.toString(), password.toString())

        // def rs = dataBaseUtilities.executeDBQuery(connection, query.toString(), filepath+"SKUORDERS"+"_"+datestring+".csv")
        //def rs = dataBaseUtilities.executePostgressquery(connection, query.toString(), "end_date")
        Proda = dataBaseUtilities.executeSAP(connection, "select count(*) from proda.salestargetmaster_itemcode;", "count")
        Prodb = dataBaseUtilities.executeSAP(connection, "select count(*) from prodb.salestargetmaster_itemcode;", "count")
        //twProd = dataBaseUtilities.executeSAP(connection, "select count(*) from proda.master_data_integration_tw;", "count")

        println("NO of records found in proda.salestargetmaster_itemcode table"+Proda)
        println("NO of records found in prodb.salestargetmaster_itemcode table"+Prodb)
        println("NO of records found in proda.master_data_integration_tw table"+twProd)
        connection.close()

        and:

        def sapconnection = dataBaseUtilities.openOracleDBConnection(dburl.toString(), dbport.toString(), user.toString(), password.toString())

        // def rs = dataBaseUtilities.executeDBQuery(connection, query.toString(), filepath+"SKUORDERS"+"_"+datestring+".csv")
        csm = dataBaseUtilities.executeSAP(sapconnection, "SELECT COUNT(*) FROM CSM.SALESTARGETMASTER_ITEMCODE;", "COUNT(*)")
       // twCSM = dataBaseUtilities.executeSAP(sapconnection, "SELECT COUNT(*) FROM CSM.MASTER_DATA_INTEGRATION_TW;", "COUNT(*)")

        println("NO of records found in CSM.SALESTARGETMASTER_ITEMCODE table"+csm)
        println("NO of records found in CSM.MASTER_DATA_INTEGRATION_TW table"+twCSM)
        sapconnection.close()



        then: "verify validations"

      //  csm == Proda
       // twProd == twCSM


        where:
        dburl | dbport | intance  | user | password | query
        dbConfig.dburl   | dbConfig.dbport | dbConfig.instance | dbConfig.dbusername | dbConfig.dbpassword | dbConfig.selectall


    }

    def "Verify Taiwan records in Postgress and SAP hana DB"() {

        given: DataBaseUtilities dataBaseUtilities = new DataBaseUtilities()

        when:


        def connection = dataBaseUtilities.openDBConnection(dburl.toString(), dbport.toString(), intance.toString(), user.toString(), password.toString())



        twProd = dataBaseUtilities.executeSAP(connection, "select count(*) from proda.master_data_integration_tw;", "count")


        println("NO of records found in proda.master_data_integration_tw table"+twProd)
        connection.close()

        and:

        def sapconnection = dataBaseUtilities.openOracleDBConnection(dburl.toString(), dbport.toString(), user.toString(), password.toString())


        twCSM = dataBaseUtilities.executeSAP(sapconnection, "SELECT COUNT(*) FROM CSM.MASTER_DATA_INTEGRATION_TW;", "COUNT(*)")


        println("NO of records found in CSM.MASTER_DATA_INTEGRATION_TW table"+twCSM)
        sapconnection.close()



        then: "verify validations"

        //  csm == Proda
        // twProd == twCSM


        where:
        dburl | dbport | intance  | user | password | query
        dbConfig.twdburl   | dbConfig.twdbport | dbConfig.instance | dbConfig.twdbusername | dbConfig.twdbpassword | dbConfig.selectall


    }

    }


