package com.tfs.common

import com.fasterxml.jackson.databind.ObjectMapper
import com.tfs.ConfigReader
import com.tfs.pages.HttpsClient_modified
import com.tfs.pages.UrlFormatter
import geb.spock.GebReportingSpec
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class eZRxelasticSearch extends GebReportingSpec {
    static ConfigObject dbConfig
    static ConfigObject config
    String resultset

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg;
        UrlFormatter.config = cfg;
        dbConfig = config.dbConfig
        //def browser = new Browser(driver)
    }


    Logger log = LoggerFactory.getLogger(eZRxelasticSearch.class)

    @Step("Call API ")
    def "Call availiability API"() {

        given: HttpsClient_modified parse = new HttpsClient_modified()
        String s=""
        ObjectMapper mapper = new ObjectMapper();

        when:
      //  String token = parse.returnToken("testdoctor@mailinator.com", "Thermofisher@123")
      //  String consulationid = parse.getConsulationid("user", "password")
        String reponse1 = parse.fetchResponse(connecturl1, customercode, shipto, salesorg, catalog, countrycode)
        String reponse2 = parse.fetchResponse(connecturl1, customercode, shipto, salesorg, catalog, countrycode)

        then: "just testing"
        reponse1.equalsIgnoreCase(reponse2)



        where:
        connecturl1 | connecturl2 |customercode | shipto  | salesorg | catalog | countrycode

        config.availaabilityV1 | config.availaabilityR1 | '0070103990' | '0070103978' | '2800' | 'AM7001' | 'us'


    }


}
