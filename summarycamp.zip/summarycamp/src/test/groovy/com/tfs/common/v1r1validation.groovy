package com.tfs.common

import com.fasterxml.jackson.databind.ObjectMapper
import com.tfs.ConfigReader
import com.tfs.pages.HttpsClient
import com.tfs.pages.HttpsClient_modified
import com.tfs.pages.UrlFormatter
import geb.spock.GebReportingSpec
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class v1r1validation extends GebReportingSpec {
    static ConfigObject dbConfig
    static ConfigObject config
    String resultset

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg;
        UrlFormatter.config = cfg;
        dbConfig = config.dbConfig
        //def browser = new Browser(driver)
    }


    Logger log = LoggerFactory.getLogger(v1r1validation.class)

    @Step("Call API ")
    def "Call availiability API"() {

        given: HttpsClient_modified parse = new HttpsClient_modified()
        String s=""
        ObjectMapper mapper = new ObjectMapper();

        when:
        String token = parse.returnToken("testdoctor@mailinator.com", "Thermofisher@123")
        String consulationid = parse.getConsulationid("user", "password")
        String reponse1 = parse.parseAPI(connecturl1, username, scid, jsonBody, catalog, countrycode)
      // String reponse2 = parse.parseAPI(connecturl2, username, scid, jsonBody, catalog, countrycode)

        then: "just testing"




        where:
        connecturl1 | connecturl2 |username | scid  | jsonBody | catalog | countrycode

        config.availaabilityV1 | config.availaabilityR1 | 'scmsnewcart@test.com' | '37977' | 'json' | 'AM7001' | 'us'


    }


}
