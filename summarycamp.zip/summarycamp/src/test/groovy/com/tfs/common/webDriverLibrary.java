package com.tfs.common;

import com.google.common.io.Files;
import geb.Browser;
import io.qameta.allure.Attachment;
import io.qameta.allure.Step;
import org.apache.commons.io.FileUtils;
import org.junit.Rule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class webDriverLibrary {
    // @Shared
    Browser browser = new Browser();
    private Set<Cookie> allCookies;

    @Step("User has logged out")
    public void signOut() throws InterruptedException {
        //Browser browser = new Browser();
        scrolltop();
        waitForElementToLoad(By.xpath("//*[@id='hfUserProfileLink']"));
        //browser.getDriver().findElement(By.xpath("//*[@id='hfUserProfileLink']")).click();
        WebElement element = browser.getDriver().findElement(By.xpath("//*[@id='hfUserProfileLink']"));
        Actions action = new Actions(browser.getDriver());
        action.moveToElement(element).perform();
        Thread.sleep(3000);
        browser.getDriver().findElement(By.xpath("//*[@id='hfB2cCmgtSignOutLink'] | //*[@id='hfCmgtAdminSignOutLi']")).click();
        Thread.sleep(10000);
    }

    @Step("Read points balance from dropdown")
    public String readpoints() throws InterruptedException {
        Browser browser = new Browser();
        scrolltop();
        waitForElementToLoad(By.xpath("//*[@id='hfUserProfileLink']"));
        //browser.getDriver().findElement(By.xpath("//*[@id='hfUserProfileLink']")).click();
        WebElement element = browser.getDriver().findElement(By.xpath("//*[@id='hfUserProfileLink']"));
        Actions action = new Actions(browser.getDriver());
        action.moveToElement(element).perform();
        Thread.sleep(1000);
        String points = browser.getDriver().findElement(By.xpath(configdataFetcher.configData("dropdownpoints"))).getText();
        screenshot(browser.getDriver());
        points = points.replaceAll("\\D+", "");
        return points;
    }


    @Step("Mouse over on the menu in home page")
    public void hoverOverToElement(By hoveritem, By clickitem) {
        Browser browser = new Browser();
        WebElement element = browser.getDriver().findElement(hoveritem);
        Actions action = new Actions(browser.getDriver());
        action.moveToElement(element).perform();
        browser.getDriver().findElement(clickitem).click();
    }


    public void waitForElementToLoad(By s1) {
//        WebDriverWait d = new WebDriverWait(browser.getDriver(), 30);
//        d.until(ExpectedConditions.visibilityOfElementLocated(s1));

        FluentWait wait = new FluentWait(browser.getDriver())
                .withTimeout(50, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.visibilityOfElementLocated(s1));


    }


    public void waitForElementToClickable(By s1) {
//        WebDriverWait d = new WebDriverWait(browser.getDriver(), 30);
//        d.until(ExpectedConditions.visibilityOfElementLocated(s1));

        FluentWait wait = new FluentWait(browser.getDriver())
                .withTimeout(50, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .ignoring(NoSuchElementException.class);
        wait.until(ExpectedConditions.elementToBeClickable(s1));


    }

    public void scroll(String locator) throws Exception {
        Browser browser = new Browser();
        WebElement scroll = browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator)));
        ((JavascriptExecutor) browser.getDriver()).executeScript("arguments[0].scrollIntoView(true);", scroll);

    }

    public void scrollbyKey(By locator) throws Exception {
        Browser browser = new Browser();
        WebElement scroll = browser.getDriver().findElement(locator);
        scroll.sendKeys(Keys.PAGE_DOWN);
        ((JavascriptExecutor) browser.getDriver()).executeScript("window.scrollTo(200, 0);");

    }

    @Step("scrolling to top of the page")
    public void scrolltop() {
        Browser browser = new Browser();
        ((JavascriptExecutor) browser.getDriver()).executeScript("window.scrollTo(0, 0);");

    }

    @Rule
    public TestWatcher screenshotOnFailure = new TestWatcher() {
        @Override
        protected void failed(Throwable e, Description description) {
            makeScreenshotOnFailure();
        }

        @Attachment("Screenshot on failure")
        public byte[] makeScreenshotOnFailure() {
            return ((TakesScreenshot) browser.getDriver()).getScreenshotAs(OutputType.BYTES);
        }
    };


    public void scrolldown(){
        Browser browser = new Browser();
        ((JavascriptExecutor) browser.getDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }

    public void selectAccountOptionItem(Browser browser,String ItemName)  {

        WebDriverWait d = new WebDriverWait(browser.getDriver(), 50);
        WebElement element = browser.getDriver().findElement(By.xpath("//a[contains( text(),\"Account\") and @id='hfUserProfileLink']"));
        Actions action = new Actions(browser.getDriver());
        action.moveToElement(element).perform();
        ((JavascriptExecutor) browser.getDriver()).executeScript("arguments[0].scrollIntoView(true);", browser.getDriver().findElement(By.xpath("//*[text()='"+ItemName+"' or @id='loyaltyLinkText']")));
        d.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='"+ItemName+"' or @id='loyaltyLinkText']")));
        browser.getDriver().findElement(By.xpath("//*[text()='"+ItemName+"' or @id='loyaltyLinkText']")).click();

    }

    @Step("Clicking on a link from home page {0}")
    public void selectSignInOptionItem(String ItemName) {
        Browser browser = new Browser();
        WebDriverWait d = new WebDriverWait(browser.getDriver(), 50);
        WebElement element = browser.getDriver().findElement(By.xpath("//a[contains( text(), 'Sign In') or @id='myaccount-button']"));
        if (ItemName.equalsIgnoreCase("Sign In")) {
            Actions action = new Actions(browser.getDriver());
            action.moveToElement(element).perform();
            d.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[contains(text(),'Sign In')])[2]")));
            browser.getDriver().findElement(By.xpath("(//*[contains(text(),'Sign In')])[2]")).click();
        } else {
            Actions action = new Actions(browser.getDriver());
            action.moveToElement(element).perform();
            ((JavascriptExecutor) browser.getDriver()).executeScript("arguments[0].scrollIntoView(true);", browser.getDriver().findElement(By.xpath("//*[text()='" + ItemName + "']")));
            d.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='" + ItemName + "']")));
            browser.getDriver().findElement(By.xpath("//*[text()='"+ItemName+"' or text()='Aspire member program']")).click();
        }
    }

    @Attachment(type = "image/png")
    public static byte[] screenshot(WebDriver driver)/* throws IOException */ {
        Random r = new Random();
        try {
            File screen = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            //File screen = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
            FileUtils.copyFile(screen, new File("C:\\code\\com.tf.loyalty\\build\\screenshots\\"+r.hashCode()+".png"));
            return Files.toByteArray(screen);
        } catch (IOException e) {
            return null;
        }
    }

    @Attachment(type = "image/png")
    public byte[] fullPage(WebDriver driver) {
        //WebDriver driver = getWebDriver();
        AShot aShot = new AShot();
        aShot.shootingStrategy(ShootingStrategies.viewportPasting(1000));
        Screenshot screenshot = aShot.takeScreenshot(driver);

        try
        {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            ImageIO.write(screenshot.getImage(), "png", stream);
            stream.flush();
            byte[] image = stream.toByteArray();
            stream.close();
            return image;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
    }
    public void saveSession(Browser browser){

        this.allCookies = browser.getDriver().manage().getCookies();
    }

    public void retainSession(Browser browser){
        browser.getDriver().manage().deleteAllCookies();
        for(Cookie cookie : allCookies)
        {
            browser.getDriver().manage().addCookie(cookie);
        }

    }

    public void mouseHoverJScript(WebElement HoverElement, WebDriver driver) {
        try {
            if (isElementPresent(HoverElement)) {

                String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
            ((JavascriptExecutor) driver).executeScript(mouseOverScript,
                    HoverElement);

        } else {
            System.out.println("Element was not visible to hover " + "\n");

        }
    } catch (StaleElementReferenceException e) {
        System.out.println("Element with " + HoverElement
                + "is not attached to the page document"
                + e.getStackTrace());
    } catch (NoSuchElementException e) {
        System.out.println("Element " + HoverElement + " was not found in DOM"
                + e.getStackTrace());
    } catch (Exception e) {
        e.printStackTrace();
        System.out.println("Error occurred while hovering"
                + e.getStackTrace());
    }
}

    public static boolean isElementPresent(WebElement element) {
        boolean flag = false;
        try {
            if (element.isDisplayed()
                    || element.isEnabled())
                flag = true;
        } catch (NoSuchElementException e) {
            flag = false;
        } catch (StaleElementReferenceException e) {
            flag = false;
        }
        return flag;
    }
    @Step("Clicking on the element: {0}")
    public void jsclick(String locator)
    {
        JavascriptExecutor executor = (JavascriptExecutor) browser.getDriver();
        WebElement element = browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator)));
        executor.executeScript("arguments[0].click();", element);
    }

    public void jsclick(WebElement element, WebDriver driver)
    {
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", element);
    }


    public void goToEnd(Browser browser){
        String selectAll = Keys.chord(Keys.CONTROL, Keys.END);
        browser.getDriver().findElement(By.tagName("html")).sendKeys(selectAll);
    }

    public String getUniqueUserId(){
        DateFormat df = new SimpleDateFormat("ddMMyyyyHHmm");
        Date date = new Date();
        String uniqeUserId = "testuser_"+df.format(date)+"@mailinator.com";
        System.out.println(uniqeUserId);
        return uniqeUserId;
    }

    public String dateTimeStamp(){
        DateFormat df = new SimpleDateFormat("ddMMyyyyHHmm");
        Date date = new Date();
        String uniqeUserId = df.format(date);
        System.out.println(uniqeUserId);
        return uniqeUserId;
    }

    public String getCurrentDate(){
        DateFormat df = new SimpleDateFormat("yyy-mm-dd");
        Date date = new Date();
        String uniqeUserId = df.format(date);
        System.out.println(uniqeUserId);
        return uniqeUserId;
    }

    public void waitForTimePeriod(long timeUnit) throws InterruptedException {
        Thread.sleep(timeUnit);
    }
    public void clickMultipleElements(String locator) {
        List<WebElement> elements = browser.getDriver().findElements(By.xpath(configdataFetcher.configData(locator)));
        for(int i=1; i<=2; i++){
            elements.get(i).click();
        }
    }


    @Step("Action click: Click using action class")
    public void actionClick(String locator) {
       WebElement element = browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator)));

        Actions action = new Actions(browser.getDriver());

       action.moveToElement(element).click().build();
       action.perform();

   }

   @Step("Copy files from all subdirectories to root")
    public void copyFiles()
   {
       Path start = Paths.get(System.getProperty("user.dir")+"\\build\\test-reports");
       int maxDepth = 30;
       try(Stream<Path> stream = java.nio.file.Files.find(start,
               maxDepth,
               (path, attr) -> String.valueOf(path).endsWith(".png"))){

           List<Path> fileName = stream
                   .sorted()
                   .filter(path -> String.valueOf(path).endsWith(".png"))
                   .collect(Collectors.toList());

           for(Path p : fileName) {
               Path path = Paths.get(System.getProperty("user.dir")+"\\build\\test-reports"+p.getFileName());
               java.nio.file.Files.copy(p, path, StandardCopyOption.REPLACE_EXISTING);
           }
       }catch(Exception e){
           e.printStackTrace();
       }
   }

   public void deleteImages()
   {
       File folder = new File(System.getProperty("user.dir")+"\\build");
       for (File file : folder.listFiles()) {
           if (file.getName().endsWith(".png")) {
               file.delete();
           }
       }
   }

    public void deleteCsv()
    {
        File folder = new File(System.getProperty("user.dir")+"\\build");
        for (File file : folder.listFiles()) {
            if (file.getName().endsWith(".csv")) {
                file.delete();
            }
        }
    }

    public void waitFor(String locator)
    {
        waitForElementToLoad(By.xpath(configdataFetcher.configData(locator)));
    }

    public void waitForClickable(String locator)
    {
        waitForElementToClickable(By.xpath(configdataFetcher.configData(locator)));
    }


    public void click(String locator)
    {
        browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator))).click();
    }
    @Step("Read text from the locator")
    public String readText(String locator)
    {
        String text = browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator))).getText();
        return text;
    }

    @Step("Type text in input box")
    public void typeText(String locator, String text)
    {
        browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator))).sendKeys(text);
    }

    @Step("navigate Back in the browser")
    public void navigateback() {

        browser.getDriver().navigate().back();
    }

    public void navigateToUrl(String url)
    {
        browser.getDriver().navigate().to(url);
    }

    @Step("Read current url of app")
    public String readCurrenturl() {

        String url = browser.getDriver().getCurrentUrl();
        return url;
    }

    @Step("upload a file")
    public void uploadFile(String locator)
    {
        String filePath=System.getProperty("user.dir")+"\\src\\test\\resources\\testimage.png";
        File pathtofile = new File (filePath);
        browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator))).sendKeys(pathtofile.toString());
    }

    @Step("upload a file")
    public void uploadFile(String locator, String filepath)
    {

        File pathtofile = new File (filepath);
        browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator))).sendKeys(pathtofile.toString());
    }

    public int clickifvisible(String locator) throws InterruptedException {
        List<WebElement> ele = browser.getDriver().findElements(By.xpath(configdataFetcher.configData(locator)));
        if(ele.size()>0)
        {
            Thread.sleep(10000);
            jsclick(ele.get(0), browser.getDriver());
        }
        return ele.size();
    }

    public void checkifVisible(String locator) {
        browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator))).isDisplayed();

    }

    public void checkNotVisible(String locator) {
        List<WebElement> elements = browser.getDriver().findElements(By.xpath(configdataFetcher.configData(locator)));
        Assert.assertEquals(elements.size(), 0);

    }

    public void clear(String locator) {
        browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator))).clear();

    }


    public void clickAnyWhere(WebDriver driver) throws AWTException {
        Actions actions = new Actions(driver);

        Robot robot = new Robot();

        robot.mouseMove(50,50);

        actions.click().build().perform();

        robot.mouseMove(200,70);

        actions.click().build().perform();
    }

    public void mouseOver(String locator, WebDriver driver) throws InterruptedException {
        Actions actions = new Actions(driver);
        WebElement element = browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator)));
        actions.moveToElement(element).perform();
        Thread.sleep(5000);
    }

    public int checkListSize(String locator)
    {
        List<WebElement> resultsize = browser.getDriver().findElements(By.xpath(configdataFetcher.configData(locator)));
        return resultsize.size();
    }

    public static void switchtonextTab(WebDriver driver)
    {
        ArrayList<String> newTb = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(newTb.get(1));

    }

    public static void switchtoOriginalTab(WebDriver driver)
    {



        String originalHandle = driver.getWindowHandle();

        //Do something to open new tabs

        for(String handle : driver.getWindowHandles()) {
            if (!handle.equals(originalHandle)) {
                driver.switchTo().window(handle);
                driver.close();
            }
        }

        driver.switchTo().window(originalHandle);
    }

    public void selectoption(String locator, String searchkey)
    {
        Select fruits = new Select(browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator))));
        fruits.selectByVisibleText(searchkey);
    }

    public void uploadFileWithRobot (String imagePath) {
        StringSelection stringSelection = new StringSelection(imagePath);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
        Robot robot = null;
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
        robot.delay(250);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.delay(150);
        robot.keyRelease(KeyEvent.VK_ENTER);
    }

    public boolean isAlertPresent() {

        boolean presentFlag = false;

        try {

            // Check the presence of alert
            Alert alert = browser.getDriver().switchTo().alert();
            // Alert present; set the flag
            presentFlag = true;
            // if present consume the alert
            alert.accept();
            //( Now, click on ok or cancel button )

        } catch (NoAlertPresentException ex) {
            // Alert not present
            ex.printStackTrace();
        }

        return presentFlag;
    }

    public void uploadFileUisngRobot(String locator, String path) throws AWTException, InterruptedException {
        try {
            JavascriptExecutor j = (JavascriptExecutor) browser.getDriver();
            StringSelection s = new StringSelection(path);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s, null);
            browser.getDriver().findElement(By.xpath(configdataFetcher.configData(locator))).click();
            Thread.sleep(6000);
            Robot r = new Robot();
            r.keyPress(KeyEvent.VK_ENTER);
            //releasing enter
           r.keyRelease(KeyEvent.VK_ENTER);

            //pressing ctrl+v
            r.keyPress(KeyEvent.VK_CONTROL);
            r.keyPress(KeyEvent.VK_V);
            //releasing ctrl+v
            r.keyRelease(KeyEvent.VK_CONTROL);
            r.keyRelease(KeyEvent.VK_V);
            //pressing enter
            r.keyPress(KeyEvent.VK_ENTER);
            //releasing enter
            r.keyRelease(KeyEvent.VK_ENTER);
        }
        catch (Exception e){
           // throw new WebDriverLibraryException("Error in uploading file using robot class");
        }
    }

}







