package com.tfs.common

class xmlUtilities {

    public static String readxml(String xmlfilepath)
    {
        try {
            BufferedReader input = new BufferedReader(new FileReader(xmlfilepath));
            StringBuffer output = new StringBuffer();
            String st;
            while ((st=input.readLine()) != null) {
                output.append(st);
            }
            System.out.println(output.toString());
            input.close();
            return output.toString()
        }
        catch (Exception fx) {
            System.out.println("Exception " + fx.toString());
        }


    }
}
