package com.tfs.constants

class GlobalConstants {
    /*static final String SVCS_PERSONA = 'Services Marketplace'
    static final String COUNTRY = 'country'
    static final String LANGUAGE = 'language'
    static final String SITE_NAME = 'siteName'
    static final String TYPE = 'type'
    static final String TERM = 'term'
    static final String TOTAL_RESULTS = 'totalResults'
    static final String FILTERS = 'filters'
    static final String NAME = 'name'
    static final String VALUES = 'values'
    static final String CATEGORY_ID = 'categoryId'
    static final String CATEGORY_NAME = 'categoryName'*/

}
