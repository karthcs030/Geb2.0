package com.tfs.features.eZRX

import com.tfs.ConfigReader
import com.tfs.pages.GlobalRegistrationPage
import com.tfs.pages.LoginPage
import com.tfs.pages.OrderConfirmationPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore
import spock.lang.Shared

class creatnewuser extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(creatnewuser.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared String ponumber

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxhome)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if(browser.driver){
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }

    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto eZRX application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxhome)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoeZRXdev(username, password)

        then: "user should be able to login sucessfully"


        where:
       username                        | password
       'karthikml' | 'Thermofisher@123456'

    }


    @Severity(SeverityLevel.CRITICAL)
    def "Manage existing users"() {

        given: "Admin is already logged in"


        when: "Admin moves to Manage users page and able to search user"
        OrderConfirmationPage users = new OrderConfirmationPage(browser)
        users.manageUser(username)


        then: "user should be able to login sucessfully"



        where:
        username | customercode | shiptono
        'automation_test_2022_08_18_04_05_31@zuellig.com' | '000100728' | '70048890'

    }

    def "create new user"() {

        given: "Admin is already logged in"


        when: "Admin moves to Manage users page and able to search user"
        GlobalRegistrationPage users = new GlobalRegistrationPage(browser)
        users.createNewEzrxuser()


        then: "user should be able to login sucessfully"



        where:
        username | customercode | shiptono
        'automation_test_2022_08_18_04_05_31@zuellig.com' | '000100728' | '70048890'

    }




}
