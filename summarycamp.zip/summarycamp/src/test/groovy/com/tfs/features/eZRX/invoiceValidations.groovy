package com.tfs.features.eZRX

import com.tfs.ConfigReader
import com.tfs.pages.LoginPage
import com.tfs.pages.OrderConfirmationPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore
import spock.lang.Shared

class invoiceValidations extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(invoiceValidations.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared String ponumber
    @Shared String returnid

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxhome)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if(browser.driver){
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }


    @Ignore
    @Step("Login to eZRX invalid password")
    @Severity(SeverityLevel.NORMAL)
    def "Loginto eZRX application with invalid username and password"() {

        given: "user is able to open url in browser"

        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoeZRX(username, password)
        login.seeErrorMsg()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer12345$'

    }

    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto eZRX application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxhome)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoeZRXdev(username, password)

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikml' | 'Thermofisher@123456'

    }

   @Severity(SeverityLevel.CRITICAL)
    def "Select shipto for a customer"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        browser.driver.navigate().refresh()
        Thread.sleep(5000)
        OrderConfirmationPage shipto = new OrderConfirmationPage(browser)
        shipto.selectShiptoDynamic(salesorg, customercode, shiptoaddress)

        then: "user should be able to login sucessfully"



        where:
        salesorg                        | customercode | shiptoaddress
        '2601 - ZP SG' | '0000100728' | '70048890'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Add additional information"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage ordercheck = new OrderConfirmationPage(browser)
        ordercheck.addAdditonalInformationMY()


        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Upload Incorrect invoice"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage ordercheck = new OrderConfirmationPage(browser)
        ordercheck.uploadIncorrectInvoice()
       // ordercheck.checkforMinimumOrderValue()

        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }



    @Severity(SeverityLevel.CRITICAL)
    def "Upload image invoice"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage ordercheck = new OrderConfirmationPage(browser)
        ordercheck.uploadInvoice()
        ordercheck.deleteInvoice()



        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Upload xls invoice"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage ordercheck = new OrderConfirmationPage(browser)
        ordercheck.uploadxlsInvoice()



        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Upload csv invoice"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage ordercheck = new OrderConfirmationPage(browser)
        ordercheck.uploadcsvInvoice()



        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }








}
