package com.tfs.features.eZRX

import com.tfs.ConfigReader
import com.tfs.pages.LoginPage
import com.tfs.pages.OrderConfirmationPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore
import spock.lang.Shared

class orderPlacementTH extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(orderPlacementTH.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared
    String ponumber
    @Shared
    String ordernumber
    @Shared
    String materialnumber

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxhome)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if (browser.driver) {
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }

    @Ignore
    @Step("Login to eZRX invalid password")
    @Severity(SeverityLevel.NORMAL)
    def "Loginto eZRX application with invalid username and password"() {

        given: "user is able to open url in browser"

        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoeZRX(username, password)
        login.seeErrorMsg()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer12345$'

    }


    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto eZRX application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxhome)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoeZRXdev(username, password)

        then: "user should be able to login sucessfully"


        where:
        username    | password
        'karthikml' | 'Thermofisher@123456'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Select shipto for a customer by passig shipcode"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage shipto = new OrderConfirmationPage(browser)
        String shiptonumber = shipto.selectShiptoDynamic(salesorg, customercode, shiptono)

        then: "user should be able to login sucessfully"
        shiptonumber.matches("[0-9]+")


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Add addditional information and place and order"() {

        given: "user is able to open url in browser and login"
        OrderConfirmationPage order = new OrderConfirmationPage(browser)


        when: "user embeds valid payment info and makes payment"
        ponumber = order.addAdditonalInformation()
        order.addItemstoCartTW()
        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Search for placed order in Order History page"() {

        given: "user is already logged in"
        OrderConfirmationPage order = new OrderConfirmationPage(browser)

        when: "user embeds valid payment info and makes payment"
        List<String> orderdetails = order.orderHistoryVerification(ponumber)
        ordernumber = orderdetails.get(0).toString()
        ordernumber = ordernumber.replaceAll("[^\\d]", "");
        materialnumber = orderdetails.get(1).toString()
        order.navigateback()
        // String currenturl = order.reorder()

        then: "user should be able to login sucessfully"
//        currenturl.contains("savedorders")
        !orderdetails.get(0).isAllWhitespace()
        orderdetails.get(3).contains("ZPOR")
        orderdetails.get(4).equalsIgnoreCase(ponumber)
        !orderdetails.get(2).startsWith("0")


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    def "Search with material name or ID"() {

        given: "user is already logged in"
        OrderConfirmationPage order = new OrderConfirmationPage(browser)

        when: "user embeds valid payment info and makes payment"
        String materials_results = order.seachwithmaterialnumber(materialnumber)

        then: "user should be able to login sucessfully"
        materials_results.contains(materialno)


        where:
        username                        | materialno
        'karthikpatient@mailinator.com' | materialnumber

    }

    def "Search with Order ID"() {

        given: "user is already logged in"
        OrderConfirmationPage order = new OrderConfirmationPage(browser)

        when: "user embeds valid payment info and makes payment"
        String materials_results = order.seachwithOrderID(ordernumber)

        then: "user should be able to login sucessfully"
        materials_results.contains(materialno)



        where:
        username                        | materialno
        'karthikpatient@mailinator.com' | ordernumber

    }

    @Ignore
    def "Export Results"() {

        given: "user is already logged in"
        OrderConfirmationPage order = new OrderConfirmationPage(browser)

        when: "user embeds valid payment info and makes payment"
        order.exportResults()

        then: "user should be able to login sucessfully"




        where:
        username                        | materialno
        'karthikpatient@mailinator.com' | '0200183189'

    }

    def "Change stauts and verify"() {

        given: "user is already logged in"
        OrderConfirmationPage order = new OrderConfirmationPage(browser)

        when: "user embeds valid payment info and makes payment"
        order.changeOrderStatusandVerify()

        then: "user should be able to login sucessfully"



        where:
        username                        | materialno
        'karthikpatient@mailinator.com' | '0200183189'

    }





}
