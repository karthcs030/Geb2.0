package com.tfs.features.eZRX

import com.tfs.ConfigReader
import com.tfs.pages.LoginPage
import com.tfs.pages.OrderConfirmationPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Shared

class orderplacemenByPrincipal extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(orderplacemenByPrincipal.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared String ponumber
    @Shared String returnid

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxhome)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if(browser.driver){
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }

    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto eZRX application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxhome)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoeZRXdev(username, password)

        then: "user should be able to login sucessfully"


        where:
       username                        | password
       'karthikml' | 'Thermofisher@123456'

    }

   @Severity(SeverityLevel.CRITICAL)
    def "Select shipto for a customer"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        browser.driver.navigate().refresh()
        Thread.sleep(5000)
        OrderConfirmationPage shipto = new OrderConfirmationPage(browser)
        shipto.selectShiptoDynamic(salesorg, customercode, shiptoaddress)

        then: "user should be able to login sucessfully"



        where:
        salesorg                        | customercode | shiptoaddress
        '2500 - ZPC PH' | '0000002512' | '0000002512'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Add additional information"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage ordercheck = new OrderConfirmationPage(browser)
        ordercheck.addAdditonalInformationMY()


        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Search with pricipal and add items to cart"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage ordercheck = new OrderConfirmationPage(browser)
        ordercheck.searchByPrincipal(principal)
        ordercheck.addItemstoCart()

        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country | principal
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY' | 'ICU Medical, Inc'

    }



    def "Search with material name or ID"() {

        given: "user is already logged in"
        OrderConfirmationPage order = new OrderConfirmationPage(browser)

        when: "user embeds valid payment info and makes payment"
        String materials_results = order.searchwithPricipalinOH(principal)

        then: "user should be able to login sucessfully"
        //materials_results.contains(principal)


        where:
        username                        | principal
        'karthikpatient@mailinator.com' | 'ICU Medical, Inc'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Logout from ezrx"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        LoginPage ordercheck = new LoginPage(browser)

        ordercheck.ezrxLogout()

        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }






}
