package com.tfs.features.eZRX

import com.tfs.ConfigReader
import com.tfs.pages.EZRxPaymentPage
import com.tfs.pages.LoginPage
import com.tfs.pages.OrderConfirmationPage
import com.tfs.pages.UrlFormatter

import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Shared

class paymentFlow extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(paymentFlow.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared String ponumber

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxhome)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if(browser.driver){
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }

    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto eZRX application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxhome)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoeZRXdev(username, password)

        then: "user should be able to login sucessfully"


        where:
       username                        | password
       'karthikml' | 'Thermofisher@123456'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Select shipto for a customer by passig shipcode"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage shipto = new OrderConfirmationPage(browser)
        String shiptonumber = shipto.selectShiptowithSalesOrg()

        then: "user should be able to login sucessfully"
        shiptonumber.matches("[0-9]+")


        where:
        username                        | password | shipcode
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119'

    }

   @Severity(SeverityLevel.CRITICAL)
    def "Select shipto for a customer"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxPaymentPage payment = new EZRxPaymentPage(browser)
       payment.validatePaymentflow()


        then: "user should be able to login sucessfully"



        where:
        username                        | password | shipcode
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119'

    }






}
