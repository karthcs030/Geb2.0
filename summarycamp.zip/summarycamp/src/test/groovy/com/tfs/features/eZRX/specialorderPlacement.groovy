package com.tfs.features.eZRX

import com.tfs.ConfigReader
import com.tfs.pages.LoginPage
import com.tfs.pages.OrderConfirmationPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore
import spock.lang.Shared

class specialorderPlacement extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(specialorderPlacement.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared String ponumber

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxhome)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if(browser.driver){
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }

    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto eZRX application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxhome)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoeZRXdev(username, password)

        then: "user should be able to login sucessfully"


        where:
       username                        | password
       'karthikml' | 'Thermofisher@123456'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Login as sales rep"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        LoginPage shipto = new LoginPage(browser)
        shipto.loginasSalesrep(salesrep)

        then: "user should be able to login sucessfully"



        where:
        salesorg | customercode | salesrep
        '2800 - ZP TW' | '0030098978' | 'fhsieh'

    }


   @Severity(SeverityLevel.CRITICAL)
    def "Select shipto for a customer by passig shipcode"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage shipto = new OrderConfirmationPage(browser)
        String shiptonumber = shipto.selectCustomercodeandShipto(customercode, shiptono)

        then: "user should be able to login sucessfully"



        where:
        salesorg | customercode | shiptono
        '2800 - ZP TW' | '0030038505' | '0070100015'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Change language code"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        LoginPage shipto = new LoginPage(browser)
        shipto.changelanguage()

        then: "user should be able to login sucessfully"



        where:
        salesorg | customercode | salesrep
        '2800 - ZP TW' | '0030098978' | 'fhsieh'

    }


    @Severity(SeverityLevel.CRITICAL)
    def "Add addditional information and place and order"() {

        given: "user is able to open url in browser and login"
        OrderConfirmationPage order = new OrderConfirmationPage(browser)


        when: "user embeds valid payment info and makes payment"
       ponumber = order.addAdditonalInformation()
        order.addItemstoCart()
        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Search for placed order in Order History page"() {

        given: "user is already logged in"
        OrderConfirmationPage order = new OrderConfirmationPage(browser)

        when: "user embeds valid payment info and makes payment"
            List<String> orderdetails = order.orderHistoryVerification(ponumber)
            order.navigateback()
            String currenturl = order.reorder()

        then: "user should be able to login sucessfully"
        currenturl.contains("savedorders")
        !orderdetails.get(0).isAllWhitespace()
        orderdetails.get(2).contains("ZPOR")
        orderdetails.get(3).equalsIgnoreCase(ponumber)
        !orderdetails.get(1).contains("0")


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }






}
