package com.tfs.features.eZRXMP

import com.tfs.ConfigReader
import com.tfs.pages.EZRxKoreaProductListingPage
import com.tfs.pages.LoginPage
import com.tfs.pages.MPordering
import com.tfs.pages.OrderConfirmationPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Shared

class searchAndSort extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(searchAndSort.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared
    String ponumber

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxhome)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if (browser.driver) {
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }



    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto eZRX application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxmphome)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoeZRXdev(username, password)

        then: "user should be able to login sucessfully"


        where:
        username    | password
        'karthikml' | 'Thermofisher@123456'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Select shipto for a customer by passig shipcode"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage shipto = new OrderConfirmationPage(browser)
        String shiptonumber = shipto.selectShiptoDynamic(salesorg, customercode, shiptono)

        then: "user should be able to login sucessfully"
        shiptonumber.matches("[0-9]+")


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Add addditional information and place and order"() {

        given: "user is able to open url in browser and login"
        MPordering order = new MPordering(browser)


        when: "user embeds valid payment info and makes payment"
        order.navigatetoMarketplace()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "view all Trending products"() {

        given: "user is able to open url in browser and login"
        EZRxKoreaProductListingPage order = new EZRxKoreaProductListingPage(browser)


        when: "user embeds valid payment info and makes payment"
        order.viewalltrndingthisweek()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "view all products"() {

        given: "user is able to open url in browser and login"
        EZRxKoreaProductListingPage order = new EZRxKoreaProductListingPage(browser)


        when: "user embeds valid payment info and makes payment"
        order.viewAllproducts()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Verify products are lsited in ascending order"() {

        given: "user is able to open url in browser and login"
        EZRxKoreaProductListingPage order = new EZRxKoreaProductListingPage(browser)


        when: "user embeds valid payment info and makes payment"
        order.ValidateProductsSortByAZ()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "search with product name"() {

        given: "user is able to open url in browser and login"
        EZRxKoreaProductListingPage order = new EZRxKoreaProductListingPage(browser)


        when: "user embeds valid payment info and makes payment"
        order.searchForTheProduct("pan")

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "search with single character"() {

        given: "user is able to open url in browser and login"
        EZRxKoreaProductListingPage order = new EZRxKoreaProductListingPage(browser)


        when: "user embeds valid payment info and makes payment"
        order.searchForTheProduct("m")

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Verify favorite is present"() {

        given: "user is able to open url in browser and login"
        EZRxKoreaProductListingPage order = new EZRxKoreaProductListingPage(browser)


        when: "user embeds valid payment info and makes payment"
        order.Verifyfavourite()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Verify sort is present"() {

        given: "user is able to open url in browser and login"
        EZRxKoreaProductListingPage order = new EZRxKoreaProductListingPage(browser)


        when: "user embeds valid payment info and makes payment"
        order.VerifySortBy()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Sort products in Z to A"() {

        given: "user is able to open url in browser and login"
        EZRxKoreaProductListingPage order = new EZRxKoreaProductListingPage(browser)


        when: "user embeds valid payment info and makes payment"
        order.clickOnSortByZA()
        order.ValidateProductsSortByZA()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }





}
