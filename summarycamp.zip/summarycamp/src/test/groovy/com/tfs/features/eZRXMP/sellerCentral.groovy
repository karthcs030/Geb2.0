package com.tfs.features.eZRXMP

import com.tfs.ConfigReader
import com.tfs.pages.EZRxMPsellerportal
import com.tfs.pages.LoginPage
import com.tfs.pages.MPordering
import com.tfs.pages.OrderConfirmationPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore
import spock.lang.Shared

class sellerCentral extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(sellerCentral.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared
    String ponumber

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxhome)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if (browser.driver) {
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }



    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto eZRX application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxmseller)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logineZRxKoreaUAT(username, password)

        then: "user should be able to login sucessfully"


        where:
        username    | password
        'marketplace-admin' | 'IGw@TG!B1$Axb'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Validate Dashbaord"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateDashbaord()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Validate Products"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateProducts()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Validate Promotions"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validatePromotions()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Ignore
    @Severity(SeverityLevel.CRITICAL)
    def "Validate Facets"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateFacets()

        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }



    @Severity(SeverityLevel.CRITICAL)
    def "Validate RMA"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateRMA()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Validate Orders"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateOrders()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Validate Buyers"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateBuyer()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Validate Sellers"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateSeller()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Validate MarketplaceAdmin"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateMarketplaceAdmin()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Validate StoreFronts"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateStoreFront()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Validate SellerProfile"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        EZRxMPsellerportal ezRxMPsellerportal = new EZRxMPsellerportal(browser)
        ezRxMPsellerportal.validateSellerProfile()
        then: "user should be able to login sucessfully"


        where:
        salesorg       | customercode | shiptono
        '2902 - ZP TH' | '0101464'    | '71057759'

    }



}
