package com.tfs.features.eZRXMP

import com.tfs.ConfigReader
import com.tfs.pages.EZRxMPsellerportal
import com.tfs.pages.LoginPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Shared

class sellerRegistration extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(sellerRegistration.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared
    String ponumber

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxsellerreg)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if (browser.driver) {
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }



    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto eZRX application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxsellerreg)

        when: "user embeds valid username and password"

        EZRxMPsellerportal login = new EZRxMPsellerportal(browser)
        login.sellerRegistration()

        then: "user should be able to login sucessfully"


        where:
        username    | password
        'marketplace-admin' | 'IGw@TG!B1$Axb'

    }


}
