package com.tfs.features.eZRxPROD

import com.tfs.ConfigReader
import com.tfs.pages.LoginPage
import com.tfs.pages.OrderConfirmationPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore
import spock.lang.Shared


class Salesrep2201ZPMM extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(Salesrep2201ZPMM.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared String ponumber
    OrderConfirmationPage ordercheck = new OrderConfirmationPage(browser)

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.ezrxhome)
        browser.baseUrl = config.ezrxhome
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if(browser.driver){
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }



    @Step("Login to eZRX")
    @Severity(SeverityLevel.CRITICAL)
    def "ezrx.com website should be reachable and User should be able to login"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.ezrxhome)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
       login.logintoeZRX(username, password)

        then: "user should be able to login sucessfully"


        where:
       username                        | password
       'karthikml' | 'Thermofisher@123456'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Login as sales rep"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        LoginPage shipto = new LoginPage(browser)
        shipto.loginasSalesrep(salesrep)

        then: "user should be able to login sucessfully"



        where:
        salesorg | customercode | salesrep
        '2800 - ZP TW' | '0030098978' | 'htetwaihtun'

    }


    @Severity(SeverityLevel.CRITICAL)
    def "User should be able to select Sales Org / Sold to Code / Ship to Code"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage shipto = new OrderConfirmationPage(browser)
        shipto.selectShiptoDynamicVN(salesorg, customercode, shiptono)

        then: "user should be able to login sucessfully"



        where:
        salesorg | customercode | shiptono
        '2201' | '30265716' | '70358122'

    }




    @Severity(SeverityLevel.CRITICAL)
    def "Click on create order and Select Payment Terms"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        OrderConfirmationPage ordercheck = new OrderConfirmationPage(browser)


        browser.driver.get(config.ezrxhome)

        String ponumber = ordercheck.addAdditonalInformationMY()


        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }




    @Severity(SeverityLevel.CRITICAL)
    def "User should be able to load materials and User should be able to adjust Quantity of materials and add to cart"() {

        given: "user is already logged in"
        ordercheck.clickifvisible("acceptcookies")

        when: "user embeds valid username and password"
        ordercheck.additemstocartProd()

        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }




    @Severity(SeverityLevel.CRITICAL)
    def "User should be able to view orders in Order History"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        browser.driver.navigate().to("https://ezrx.com/order")

        ordercheck.orderHistoryVerificationPROD("testing")

        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }



    @Severity(SeverityLevel.CRITICAL)
    def "Logout from ezrx"() {

        given: "user is already logged in"


        when: "user embeds valid username and password"
        LoginPage ordercheck = new LoginPage(browser)

        ordercheck.ezrxLogout()

        then: "user should be able to login sucessfully"


        where:
        username                        | password | shipcode | country
        'testdoctor@mailinator.com' | 'Thermofisher@123' | '30037119' | 'MY'

    }


}
