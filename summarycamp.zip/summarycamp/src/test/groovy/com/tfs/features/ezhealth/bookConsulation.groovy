package com.tfs.features.ezhealth

import com.tfs.ConfigReader

import com.tfs.pages.ConsultationPage
import com.tfs.pages.LoginPage
import com.tfs.pages.PaymentPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class bookConsulation extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(bookConsulation.class)
    static ConfigObject config

    static ConfigObject loginConfig

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.home)
        browser.baseUrl = config.home
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if(browser.driver){
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }

  @Step("Login to EZhealth invalid password")
    @Severity(SeverityLevel.NORMAL)
    def "Loginto EZHealth application with invalid username and password"() {

        given: "user is able to open url in browser"

        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoEZHealth(username, password)
        login.seeErrorMsg()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer12345$'

    }


    @Step("Login to EZhealth")
    @Severity(SeverityLevel.CRITICAL)
    def "Loginto EZHealth application with valid username and password"() {

        given: "user is able to open url in browser"
        browser.driver.get(config.home)
        when: "user embeds valid username and password"
        LoginPage login = new LoginPage(browser)
        login.logintoEZHealth(username, password)

        then: "user should be able to login sucessfully"


        where:
       username                        | password
       'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Book a Self consulation from patient module"() {

        given: "user is able to open url in browser"
        LoginPage login = new LoginPage(browser)
        when: "user embeds valid username and password"
        ConsultationPage consult = new ConsultationPage(browser)
        consult.bookSelfConsulation()
        consult.checkAppoinmentStatus()
        login.logout()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Login as Doctor and accept consulation"() {

        given: "user is able to open url in browser"
        LoginPage login = new LoginPage(browser)
        login.logintoEZHealth(username, password)

        when: "user embeds valid username and password"
        ConsultationPage consult = new ConsultationPage(browser)
        consult.acceptConsulation()
        login.logout()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'testdoctor@mailinator.com' | 'Thermofisher@123'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Login as Patient  and try to book another consulation"() {

        given: "user is able to open url in browser and login"
        LoginPage login = new LoginPage(browser)
        login.logintoEZHealth(username, password)

        when: "user embeds valid payment info and makes payment"
        ConsultationPage consult = new ConsultationPage(browser)
        consult.bookSelfConsulation()
        consult.paymentPending()

        then: "user should be able to login sucessfully"


        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Login as Patient  and Make Payment for booked Consultation"() {

        given: "user is already logged in"


        when: "user embeds valid payment info and makes payment"
        PaymentPage pay = new PaymentPage(browser)
        pay.navigateToPayment()
        pay.chooseAppointmentforPayment()
        String currenturl = pay.payThoughCredicard()

        then: "user should be able to login sucessfully"
        currenturl.contains("patient/paymentinformation")

        where:
        username                        | password
        'karthikpatient@mailinator.com' | 'Qwer1234$'

    }






}
