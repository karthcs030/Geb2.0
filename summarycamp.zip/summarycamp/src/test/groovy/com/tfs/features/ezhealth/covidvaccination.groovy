package com.tfs.features.ezhealth

import com.tfs.ConfigReader
import com.tfs.pages.GlobalRegistrationPage
import com.tfs.pages.LoginPage
import com.tfs.pages.UrlFormatter
import com.tfs.pages.VaccinationPage
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore
import spock.lang.Shared

class covidvaccination extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(covidvaccination.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared String username;
    @Shared String password

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.home)
        browser.baseUrl = config.home
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if(browser.driver){
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }




    @Severity(SeverityLevel.CRITICAL)
    def "Login as Admin and Approve Doctor"() {

        given: "user is able to open url in browser"
        LoginPage login = new LoginPage(browser)
        login.logintoEZHealth(rootname, rootpassword)

        when: "user embeds valid username and password"
        VaccinationPage consult = new VaccinationPage(browser)
        consult.registerForVaccine()
        login.logout()

        then: "user should be able to login sucessfully"


        where:
        rootname                        | rootpassword
        'testuser_210720221414@mailinator.com' |  'Qwer1234@'

    }


}
