package com.tfs.features.ezhealth

import com.tfs.ConfigReader
import com.tfs.pages.GlobalRegistrationPage
import com.tfs.pages.LoginPage
import com.tfs.pages.UrlFormatter
import geb.driver.CachingDriverFactory
import geb.spock.GebReportingSpec
import io.qameta.allure.Severity
import io.qameta.allure.SeverityLevel
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Ignore
import spock.lang.Shared

class doctorRegistration extends GebReportingSpec {

    Logger log = LoggerFactory.getLogger(doctorRegistration.class)
    static ConfigObject config

    static ConfigObject loginConfig
    @Shared String username;
    @Shared String password

    def setupSpec() {
        ConfigObject cfg = ConfigReader.getConfiguration()
        config = cfg
        UrlFormatter.config = cfg
        browser.driver.get(config.home)
        browser.baseUrl = config.home
        waitFor { js.('document.readyState') == 'complete' }
        loginConfig = config.loginFlowConfig
    }

    def cleanupSpec() {
        if(browser.driver){
            CachingDriverFactory.clearCache()
            browser.driver.quit()
        }
    }

  @Step("Create new patient account through sign up link")
    @Severity(SeverityLevel.NORMAL)
    def "Create new patient account"() {

        given: "user is able to open url in browser"

        when: "user embeds valid username and password"
        GlobalRegistrationPage reg = new GlobalRegistrationPage(browser)
      List<String> logindetails = reg.register("doctor")
      username = logindetails.get(0)
      password = logindetails.get(1)


        then: "user should be able to login sucessfully"

    }

    @Severity(SeverityLevel.CRITICAL)
    def "Login as Admin and Approve Doctor"() {

        given: "user is able to open url in browser"
        LoginPage login = new LoginPage(browser)
        login.logintoEZHealth(rootname, rootpassword)

        when: "user embeds valid username and password"
        GlobalRegistrationPage consult = new GlobalRegistrationPage(browser)
        consult.approveDoctor(username)
        login.logout()

        then: "user should be able to login sucessfully"


        where:
        rootname                        | rootpassword
        'ezconsult_root' |  'ezconsult_admin'

    }

    @Ignore
    @Step("Login to EZhealth invalid password")
    @Severity(SeverityLevel.NORMAL)
    def "Accept terms and update account infromation"() {

        given: "user is able to open url in browser"
        LoginPage login = new LoginPage(browser)
        login.logintoEZHealth(username, password)

        when: "user embeds valid username and password"
        GlobalRegistrationPage reg = new GlobalRegistrationPage(browser)
        reg.patientAcceptTerms();
        reg.updateAccountInformation();
        reg.updateAddressBook()


        then: "user should be able to login sucessfully"

    }











}
