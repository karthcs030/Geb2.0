package com.tfs.pages


import com.tfs.common.webDriverLibrary
import geb.Browser
import io.qameta.allure.Step

//import BaseGebSpec

//import geb.Page

class ConsultationPage extends webDriverLibrary {
    static Browser browser

    ConsultationPage(Browser browser){
        this.browser=browser
    }

    @Step("Book a Self consulation")
    def bookSelfConsulation()
    {
        waitForClickable("healthservices")
        click("healthservices")
        waitForClickable("myself")
        click("myself")
        waitForClickable("fever")
        click("fever")
        waitFor("others")
        click("others")
        waitForClickable("next")
        click("next")
        waitForClickable("cardiology")
        click("cardiology")
        waitForClickable("testdoctor")
        click("testdoctor")
        waitForClickable("bookappointment")
        Thread.sleep(5000)
        click("bookappointment")
        waitForClickable("afternoon")
        click("afternoon")
        waitForClickable("confirmappointment")
        click("confirmappointment")

    }

    @Step("Wait for error message to appear")
    def seeErrorMsg()
    {
        waitFor("errormsg")
        readText("errormsg")
    }

    @Step("Accept Consulation from Doctor's module")
    def acceptConsulation()
    {
        waitFor("agree")
        click("agree")
        waitForClickable("viewpatientprofile")
        click("viewpatientprofile")
        waitFor("bmi")
        navigateback()
        waitForClickable("accept")
        click("accept")
        Thread.sleep(10000)
        waitForClickable("queue")
        click("queue")
        waitFor("unpaid")

    }

    def checkAppoinmentStatus()
    {
        waitFor("status")
        screenshot(browser.driver)
    }

    def paymentPending()
    {
        waitFor("paymentpending")
        click("ok")
        screenshot(browser.driver)
        waitFor("close")
        click("close")
        waitFor("bookappointment")

    }




}

