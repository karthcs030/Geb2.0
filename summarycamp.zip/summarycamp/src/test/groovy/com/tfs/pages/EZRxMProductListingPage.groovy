package com.tfs.pages;

import com.tfs.common.webDriverLibrary
import geb.Browser
import io.qameta.allure.Step
import org.openqa.selenium.By
import org.openqa.selenium.WebElement
import org.testng.Assert

class EZRxKoreaProductListingPage extends webDriverLibrary {

    static Browser browser

    EZRxKoreaProductListingPage(Browser browser) {
        this.browser = browser
    }

    def viewAllproducts()
    {
        waitForClickable("viewallproducts")
        Thread.sleep(5000)
        click("viewallproducts")
        waitFor("searchProduct")
    }

    def viewalltrndingthisweek()
    {
        waitForClickable("viewalltrndingthisweek")
        Thread.sleep(5000)
        click("viewalltrndingthisweek")
        waitFor("searchProduct")
        navigateback()
    }

    @Step("click on Search")
    def clickOnSearch() {
        waitForTimePeriod(1000)
        waitFor("searchProduct")
        click("searchProduct")
    }

    @Step("Validate Recent is visible on Search")
    def validateSearchRecent() {
        waitForTimePeriod(7000)
        waitFor("searchRecent")
        checkifVisible("searchRecent")
    }

    @Step("Search for the product")
    def searchForTheProduct(String productName) {
        waitForTimePeriod(1000)
        typeText("searchProduct", productName)
        waitForTimePeriod(5000)
        waitForClickable("searchIcon")
        jsclick("searchIcon")
        waitForTimePeriod(5000)
        clear("searchProduct")
    }

    @Step("Search Product with single character")
    def searchProductWithSingleCharacter(String productName) {
        waitForTimePeriod(3000)
        typeText("searchProduct", productName)
        waitForTimePeriod(8000)
    }

    @Step("Click on cart button under ProductListing page")
    def clickOnCartBtnUnderProductListingPage() {
        waitForTimePeriod(2000)
        actionClick("homepageCart")
    }

    @Step("Click on Cart icon button")
    def clickOnCartIconBtn() {
        waitForTimePeriod(1000)
        click("cartIcon")
    }

    @Step("Click on View Cart & checkout button")
    def clickOnViewCartCheckoutBtn() {
        waitForTimePeriod(1000)
        click("viewCartAndCheckout")
    }

    @Step("Verify favourite is visible on ProductListing screen")
    def Verifyfavourite() {
        waitForTimePeriod(2000)
        checkifVisible("favouritemp")
    }

    @Step("Verify Sort By is visible on ProductListing screen")
    def VerifySortBy() {
        waitForTimePeriod(2000)
        checkifVisible("sortBy")
    }

    @Step("Click on Arrow button to collapse on ProductListing screen")
    def clickOnArrowBtn() {
        waitForTimePeriod(2000)
        checkifVisible("sortByArrow")
        click("sortByArrow")
    }

    @Step("Verify Temperature Sensitive is visible on ProductListing screen")
    def VerifyTemperatureSensitive() {
        waitForTimePeriod(2000)
        checkifVisible("temperatureSensitive")
    }

    @Step("Click on Temperature Sensitive Arrow button to collapse on ProductListing screen")
    def clickOnTemperatureSensitiveArrowBtn() {
        waitForTimePeriod(2000)
        checkifVisible("temperatureSensitiveArrow")
        click("temperatureSensitiveArrow")
    }

    @Step("Verify Brand is visible on ProductListing screen")
    def VerifyBrand() {
        waitForTimePeriod(2000)
        checkifVisible("brand")
    }

    @Step("Click on Brand Arrow button to collapse on ProductListing screen")
    def clickOnBrandArrowBtn() {
        waitForTimePeriod(2000)
        checkifVisible("brandArrow")
        click("brandArrow")
    }

    @Step("Verify Manufacturer is visible on ProductListing screen")
    def VerifyManufacturer() {
        waitForTimePeriod(2000)
        checkifVisible("manufacturer")
    }

    @Step("Click on Manufacturer Arrow button to collapse on ProductListing screen")
    def clickOnManufacturerArrowBtn() {
        waitForTimePeriod(2000)
        checkifVisible("manufacturerArrow")
        click("manufacturerArrow")
    }

    @Step("Click on Sort By A-Z on ProductListing screen")
    def clickOnSortByAZ() {
        waitForTimePeriod(2000)
        checkifVisible("sortByAZ")
        click("sortByAZ")
    }

    @Step("Verify Load More Products is visible on ProductListing screen")
    def verifyLoadMoreProducts() {
        waitForTimePeriod(2000)
        mouseOver("loadMoreProduct")
    }



    @Step("Validate Products get Sort By A-Z on ProductListing screen")
    def ValidateProductsSortByAZ() {
        waitForTimePeriod(7000)
        List<WebElement> ele = browser.getDriver().findElements(By.xpath("//div[contains(@class,'styles_productContainer')]/div[2]/span/span[2]"))

        for (int i = 0; i < ele.size(); i++) {
            //System.out.println(ele.get(i).getText())
            String productName = ele.get(i).getText()
            if (productName.startsWith("\\d.") || productName.startsWith("[0-9].*") || productName.startsWith("^[A-D].*\$") || productName.startsWith("^[a-d].*\$")) {
                Assert.assertTrue(true)
            } else {
                Assert.assertFalse(false)
            }

        }

    }

    @Step("Click on Sort By Z-A on ProductListing screen")
    def clickOnSortByZA() {
        waitForTimePeriod(2000)
        checkifVisible("sortByZA")
        click("sortByZA")
    }

    @Step("Validate Products get Sort By Z-A on ProductListing screen")
    def ValidateProductsSortByZA() {
        waitForTimePeriod(7000)
        List<WebElement> ele = browser.getDriver().findElements(By.xpath("//div[contains(@class,'styles_productContainer')]/div[2]/span/span[2]"))

        for (int i = 0; i < ele.size(); i++) {
            //System.out.println(ele.get(i).getText())
            String productName = ele.get(i).getText()
            if (productName.startsWith("\\d.") || productName.startsWith("[0-9].*") || productName.startsWith("^[R-Z].*\$") || productName.startsWith("^[r-z].*\$")) {
                Assert.assertTrue(true)
            } else {
                Assert.assertFalse(false)
            }
        }
    }

    @Step("Validate multiple product is displayed when search with single character")
    def validateMultipleProductDisplayedWhenSearchWithSingleChar(String ch) {
        waitForTimePeriod(1000)
        List<WebElement> ele = browser.getDriver().findElements(By.xpath("//div[@id='recent']/div/p"))
        for (int i = 0; i < ele.size(); i++) {
            String products = ele.get(i).getText()
            if(products.contains(ch)){
                Assert.assertTrue(true)
            }else{
                Assert.assertFalse(false)
            }
        }
    }

    @Step("Validate message when enter invalid product name")
    def validateMessageWhenEnterInvalidProduct(){
        waitForTimePeriod(2000)
        checkifVisible("searchInvalidProductMsg")
        waitForTimePeriod(2000)
    }

    @Step("Click on search product with single character")
    def clickOnProductDisplayedWhenSearchWithSingleChar(){
        waitForTimePeriod(1000)
        checkifVisible("searchProductIndex1")
        click("searchProductIndex1")
        waitForTimePeriod(2000)
    }
}