package com.tfs.pages;

import com.tfs.common.webDriverLibrary
import geb.Browser
import io.qameta.allure.Step
import org.openqa.selenium.By
import org.openqa.selenium.WebElement
import org.testng.Assert

class EZRxMPsellerportal extends webDriverLibrary {

    static Browser browser

    EZRxMPsellerportal(Browser browser) {
        this.browser = browser
    }

   def validateDashbaord()
   {
       waitForClickable("welcomemessage")
       checkifVisible("selectseller")
       checkifVisible("exportdashbord")
       waitForClickable("exportdashbord")
       click("exportdashbord")
       Thread.sleep(10000)
       checkifVisible("dailyorders")
       checkifVisible("orderstatus")
       checkifVisible("ordervaluemp")

   }

    def validateProducts()
    {
        scrolltop()
        waitForClickable("products")
        clickifvisible("products")
        commondashboard("Paracetamol")
        waitFor("manualentry")
        click("manualentry")
        scroll("productname")
        waitFor("productname")
        navigateback()

    }

    def validatePromotions()
    {
        scrolltop()
        waitForClickable("promotions")
        click("promotions")
        commondashboard("5% off select products")
        waitFor("discountcode")
        Thread.sleep(2000)

        navigateback()

    }

    def validateFacets()
    {
        scrolltop()
        waitForClickable("facets")
        click("facets")
        commondashboard("Package")
        waitFor("facetid")
        Thread.sleep(2000)

        navigateback()

    }

    def validateOrders()
    {
        scrolltop()
        waitForClickable("orderssummary")
        click("orderssummary")
        searchAndFetch("ZPMY000159")
        waitFor("orderstatusmp")
        Thread.sleep(2000)

      //  navigateback()

    }

    def validateRMA()
    {
        scrolltop()
        waitForClickable("rma")
        click("rma")
        Thread.sleep(20000)
        searchAndFetch("ZPMY000096-9xVgG7FdZ0usHjGbyNnqkA-RMA-01")
        waitFor("returntable")
        Thread.sleep(2000)

      //  navigateback()

    }

    def validateBuyer()
    {
        scrolltop()
        waitForClickable("buyers")
        click("buyers")
        searchAndFetch("eZRx Marketplace Malaysia")
        waitFor("buyername")
        Thread.sleep(2000)

       // navigateback()

    }

    def validateSeller()
    {
        scrolltop()
        waitForClickable("sellerrs")
        click("sellerrs")
        Thread.sleep(20000)
        searchAndFetch("Krishan Pvt Ltd New")
        waitFor("buyername")
        Thread.sleep(2000)

     //   navigateback()

    }

    def validateMarketplaceAdmin()
    {
        scrolltop()
        waitForClickable("marketplaceadmin")
        click("marketplaceadmin")
        Thread.sleep(20000)
        commondashboard("ideateadmin")
        waitFor("newuser")
        Thread.sleep(2000)

           navigateback()

    }

    def validateStoreFront()
    {
        scrolltop()
        waitForClickable("storefroont")
        click("storefroont")
        Thread.sleep(20000)
        commondashboard("Test storefront")
        waitFor("newstorefront")
        Thread.sleep(2000)

        navigateback()

    }

    def validateSellerProfile()
    {
        scrolltop()
        waitForClickable("sellerprofile")
        click("sellerprofile")
        /*Thread.sleep(20000)
        commondashboard("Test storefront")
        waitFor("newstorefront")
        Thread.sleep(2000)*/

        navigateback()

    }

    def commondashboard(String keyword)
    {
        waitForClickable("productsearch")
        typeText("productsearch", keyword)
        waitFor("rowresult")
        String rowresult = readText("rowresult")
        println("row results found are"+rowresult)

        scrolltop()

        waitForClickable("newproduct")
        click("newproduct")

    }

    def searchAndFetch(String keyword)
    {
        waitForClickable("productsearch")
        typeText("productsearch", keyword)
        waitFor("rowresult")
        String rowresult = readText("rowresult")
        println("row results found are"+rowresult)
        click("rowresult")
        Thread.sleep(2000)
    }

    def sellerRegistration()
    {
        waitForClickable("companyname")
        typeText("companyname", "testcopany")
        waitForClickable("regno")
        typeText("regno", "testcopany12345")
        waitFor("selectlicense")
        selectoption("selectlicense", "Manufacturer")
        uploadFile("uploadlicense")
        typeText("firslineaddress", "first line test address")
        typeText("secondaddressline", "second line test address")
        typeText("suppliercity", "TestasCity")
        typeText("supplierpostcode", "56003")
        selectoption("selectstate", "Perak")
        //selectoption("selectcountry", "Perak")
        typeText("adminfirstname", "adminfirstname")
        typeText("adminlastname", "adminlastname")
        String mailid = getUniqueUserId();
        typeText("adminemail", mailid)
        typeText("adminpassword", "Password@123")
        typeText("adminconfirmpassword", "Password@123")
        uploadFile("uploadlicensedoc")
        waitForClickable("register")
        scroll("register")
        Thread.sleep(10000)
        jsclick("register")
        waitFor("Thankyouseller")

    }


}