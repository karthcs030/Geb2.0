package com.tfs.pages

import com.tfs.common.webDriverLibrary
import geb.Browser

//import BaseGebSpec

import org.openqa.selenium.Keys
import org.openqa.selenium.WebElement

//import geb.Page

class EZRxPaymentPage extends webDriverLibrary{
    static Browser browser

    EZRxPaymentPage(Browser browser){
        this.browser=browser
    }

    def navigatetoPayment()
    {
        waitForClickable("payments")
        click("payments")
        Thread.sleep(10000)
    }

   def validatePaymentflow() {

       waitForClickable("payments")
       click("payments")
       Thread.sleep(10000)
       waitForClickable("overdue")
       checkifVisible("outstanding")
       checkifVisible("paymentinprogress")
      /* waitForClickable("viewmore")
       click("viewmore")
       waitForClickable("viewless")
       click("viewless")*/
       waitForClickable("viewallinvoices")
       click("viewallinvoices")
       waitForClickable("downloadinvoices")
       Thread.sleep(10000)
       click("downloadinvoices")
       Thread.sleep(10000)
       navigateback()
       waitForClickable("viewallpayments")
       click("viewallpayments")
       waitForClickable("downloadinvoices")
       Thread.sleep(10000)
       click("downloadinvoices")
       Thread.sleep(10000)
       navigateback()
       scrolltop()
       waitForClickable("allcredits")
       click("allcredits")
       waitForClickable("downloadinvoices")
       Thread.sleep(10000)
       click("downloadinvoices")
       Thread.sleep(10000)

   }

    def readInvoice()
    {
        String originalHandle = browser.driver.getWindowHandle();

        waitForClickable("newpayment")
        click("newpayment")
        waitForClickable("firstpayment")
        waitForClickable("invoiceno")
        click("invoiceno")
        Thread.sleep(5000)
        switchtonextTab(browser.driver)
        waitFor("customername")
        readText("customername")
        readText("payer")
        readText("shiptoinv")
        readText("duedate")
        readText("invoicenoinv")
        readText("invoicedate")
        readText("invoiceamount")
        readText("orderidinv")
        readText("invstatus")
        checkifVisible("invtable")



        //Do something to open new tabs

        for(String handle : browser.driver.getWindowHandles()) {
            if (!handle.equals(originalHandle)) {
                browser.driver.switchTo().window(handle);
                browser.driver.close();
            }
        }

        browser.driver.switchTo().window(originalHandle);
       // browser.driver.close();
    }

    def makePaymentMY()
    {
        //switchtoOriginalTab(browser.driver)
        //browser.driver.switchTo().defaultContent()
        waitForClickable("firstpayment")
        click("firstpayment")
        waitFor("paymentdue")
        waitForClickable("nextpayment")
        click("nextpayment")
        Thread.sleep(10000)
        waitForClickable("backpayment")
        click("backpayment")
        waitForClickable("nextpayment")
        click("nextpayment")
        waitForClickable("nextpayment")
        click("nextpayment")
        switchtonextTab(browser.driver)
        waitFor("price")
        waitForClickable("testcustomer")
        typeText("testcustomer", "test customer")
        waitForClickable("cardnumber1")
        typeText("cardnumber1", "4444")
        isAlertPresent()
        typeText("cardnumber2", "3333")
        isAlertPresent()
        typeText("cardnumber3", "2222")
        isAlertPresent()
        typeText("cardnumber4", "1111")
        isAlertPresent()
        selectoption("selectmonth", "12")
        selectoption("selectyear", "2035")
        typeText("ezrxcvv", "123")
        waitForClickable("ezrxsubmitpayment")
        click("ezrxsubmitpayment")
        waitForClickable("thankyoucontent")
    }

    def makePaymentSG()
    {
        //switchtoOriginalTab(browser.driver)
        //browser.driver.switchTo().defaultContent()
        waitForClickable("firstpayment")
        click("firstpayment")
        waitFor("paymentdue")
        waitForClickable("nextpayment")
        click("nextpayment")
        Thread.sleep(10000)
        waitForClickable("backpayment")
        click("backpayment")
        waitForClickable("nextpayment")
        click("nextpayment")
        waitForClickable("nextpayment")
        click("nextpayment")
        switchtonextTab(browser.driver)
        Thread.sleep(15000)
        screenshot(browser.driver)
        switchtoOriginalTab(browser.driver)
    }

    def void makePaymentTH() {

        waitForClickable("firstpayment")
        click("firstpayment")
        waitFor("paymentdue")
        waitForClickable("nextpayment")
        click("nextpayment")
        Thread.sleep(10000)
        waitForClickable("backpayment")
        click("backpayment")
        waitForClickable("nextpayment")
        click("nextpayment")
        waitForClickable("nextpayment")
        click("nextpayment")
        switchtonextTab(browser.driver)
        Thread.sleep(5000)
        waitForClickable("paybutton")
        click("paybutton")
        waitFor("processing")
        waitFor("QRcode")

    }
}

