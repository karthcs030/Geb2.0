package com.tfs.pages

import com.tfs.ConfigReader
import com.tfs.common.webDriverLibrary
import com.tfs.common.configdataFetcher
import geb.Browser
import io.qameta.allure.Step
import org.openqa.selenium.By
import org.openqa.selenium.WebElement
import org.openqa.selenium.support.ui.Select

class GlobalRegistrationPage extends webDriverLibrary{

    static Browser browser
    Random r = new Random()


    GlobalRegistrationPage(Browser browser){
        this.browser=browser
    }

    @Step("Register as new Doctor/Patient")
    def register(String accounttype)
    {

        waitForClickable("signup")
        click("signup")

        if(accounttype.equalsIgnoreCase("doctor"))
        {
            waitFor("signupdoctor")
            click("signupdoctor")
        }
        waitFor("firstname")
        typeText("firstname", "testuser")
        typeText("lastname","lastname")
        waitFor("email")
        String userid=getUniqueUserId()
        typeText("email", userid)
        waitFor("password_reg")
        String password = "Qwer1234@";
        typeText("password_reg", password)
        typeText("confirmpassword", password)
        click("selectgender")
        waitFor("female")
        click("female")
        waitForClickable("phonenumber")
        typeText("phonenumber", "1234567890")
        if(accounttype.equalsIgnoreCase("doctor"))
        {
            waitForClickable("specialist")
            Thread.sleep(5000)
            click("specialist")
        }
        waitForClickable("checkbox1")
        click("checkbox1")
        waitForClickable("closeterms")
        click("closeterms")
        waitForClickable("checkboxtext")
        click("checkboxtext")
        waitForClickable("checkbox2")
        click("checkbox2")
        waitForClickable("submit_reg")
        click("submit_reg")
        waitFor("registrationsucess")
        waitForClickable("signin")
        click("signin")
        return Arrays.asList(userid, password)

    }

    def patientAcceptTerms()
    {
        waitForClickable("subscribe")
        click("subscribe")
        waitForClickable("acceptterms1")
        click("acceptterms2")
        Thread.sleep(1000)
        click("acceptterms1")
        waitForClickable("save")
        click("save")

        Thread.sleep(5000)
        clickifvisible("skip")
        clickifvisible("skip")


    }

    def updateAccountInformation()
    {

        waitForClickable("healthservices")
        click("healthservices")
        Thread.sleep(10000)
        clickifvisible("skip")
        waitForClickable("gotoaccount")
        click("gotoaccount")
        waitForClickable("weight")
        typeText("weight", "68")
        typeText("height", "173")
        waitForClickable("employeeid")
        typeText("employeeid", "12345")
        uploadFile("governmentid")
        uploadFile("seniorcitizencard")
        uploadFile("pwdcard")
        waitForClickable("saveaccountinfo")
        click("saveaccountinfo")
        Thread.sleep(10000)

    }

    def updateAddressBook()
    {
        navigateToUrl("https://ezconsult-webapp-staging.azurewebsites.net/patient/address")
        waitForClickable("add")
        Thread.sleep(5000)
        click("add")
        waitForClickable("home")
        click("home")
        typeText("detailaddress", "default address singapore")
        typeText("postalcode", "560035")
        typeText("linenumber", "560035")
        typeText("mobilenumber", "1234567890")
        waitForClickable("default")
        click("default")
        waitForClickable("submitaddress")
        click("submitaddress")
        waitFor("defaultribbon")
        waitFor("edit")
        waitFor("delete")

    }

    def approveDoctor(String username) {

        waitForClickable("doctors")
        click("doctors")
        waitForClickable("searchbyemail")
        typeText("searchbyemail", username)
        waitForClickable("search")
        click("search")
        waitFor("mailid")
        readText("mailid")
        waitForClickable("action")
        click("action")
        waitForClickable("updatestatus")
        click("updatestatus")
        waitForClickable("approved")
        Thread.sleep(3000)
        jsclick("approved")
        waitForClickable("savedoctorstatus")
        click("savedoctorstatus")
        waitFor("updatealert")



    }

    def createNewEzrxuser()
    {

        Thread.sleep(10000)
        waitForClickable("adduser")
        jsclick("adduser")
        waitForClickable("nusername")
        String userid=getUniqueUserId()
        typeText("nusername", "userid")
        typeText("nuemail", userid)
        typeText("nufirstname", "autofirstname")
        typeText("nulastname", "autolastname")
        waitForClickable("cuntrycode")
        click("cuntrycode")
        waitForClickable("select63")
        click("select63")
        waitForClickable("numobile")
        click("numobile")
        Thread.sleep(2000)
        typeText("numobile", "1234567890")
        waitForClickable("userrole")
        click("userrole")
        waitForClickable("role")
        click("role")
        waitFor("nusalesorg")
        typeText("nusalesorg", "2601")
        waitForClickable("nuadd")
        click("nuadd")
        waitForClickable("allcustomercode")
        click("allcustomercode")
        waitForClickable("nuaddsalesorg")
        click("nuaddsalesorg")
        waitFor("salerorgaddition")
        waitForClickable("nupassword")
        typeText("nupassword", "Automation@123")
        typeText("nuconfirmpassword", "Automation@123")
        waitForClickable("mobileaccess")
        click("mobileaccess")
        waitForClickable("2fa")
        click("2fa")
        waitForClickable("adminpo")
        click("adminpo")
        waitForClickable("nuadduser")
        click("nuadduser")



    }
}
