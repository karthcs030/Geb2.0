package com.tfs.pages

import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.util.JSONPObject
import com.google.gson.JsonObject
import org.json.JSONArray

//import org.json.*
import org.json.JSONException;
import org.json.JSONObject;
import geb.Browser
import io.qameta.allure.Step
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLPeerUnverifiedException

public class HttpsClient {


    @Step("For username {2} and for catalognumber {5} result")
    public String parseAPI(String apiurl, String userName, String scid, String jsonBody, String catalogNumber, String countrycode){

       String https_url = "https://ezconsult-strapi-staging.azurefd.net/consultations/143171";
       // String https_url = apiurl;
        URL url;
        try {

            url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
            con.setRequestMethod("PUT")

                    con.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2NTkxNzMzMjMsImlhdCI6MTY1OTA4NjkyMywiaWQiOjI1NzQ1NzksInJpZ2h0cyI6bnVsbCwicm9sZSI6IkF1dGhlbnRpY2F0ZWQiLCJ1c2VybmFtZSI6InRlc3Rkb2N0b3JAbWFpbGluYXRvci5jb20ifQ.zPo4IvPsVmUVXC1qgB_OX7XCo1MDqZnPZlgRKp7D7tw")

            con.setRequestProperty("Content-Type", "application/json")
            con.setDoOutput(true)
            con.setDoInput(true)
            OutputStream os = con.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
            osw.write("{\n" +
                    "\n" +
                    "\"patient_id\": \"2574579\",\n" +
                    "\n" +
                    "\"doctor_id\": \"2576619\",\n" +
                    "\n" +
                    "\"consultation_status\": \"doctor confirmed\",\n" +
                    "\n" +
                    "\"chatsession_id\": \"62971513cb99d8000b538366\",\n" +
                    "\n" +
                    "\"freeConsultation\": false\n" +
                    "\n" +
                    "}");
            osw.flush();
            osw.close();
            os.close();

            println("Response code found was"+con.getResponseCode())

            return print_content(con)


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private InputStream getInputStream(String urlStr, String user, String password, String scid, String country, String something) throws IOException {
        String https_url = urlStr;
        URL url;
        try {

            url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("POST")

            //con.setRequestProperty("userName", userName)
            con.setRequestProperty("languageCode", "en")
            /*con.setRequestProperty("countryCode", countrycode)
            con.setRequestProperty("scid", scid)
            con.setRequestProperty("newCart", "true") */
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true)
            OutputStream os = con.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
            osw.write("{\n" +
                    "    \"userName\": \"cart.us@test.com\",\n" +
                    "    \"createNewCart\": true,\n" +
                    "    \"cartRequest\": {\n" +
                    "        \"lineItems\": [\n" +
                    "            {\n" +
                    "                \"lineNo\": 1,\n" +
                    "                \"quantity\": 1,\n" +
                    "                \"product\": {\n" +
                    "                    \"sku\": \"815020DE\",\n" +
                    "                    \"description\": \"GeneArt Strings(TM) DNA Fragment\",\n" +
                    "                    \"productSize\": \"1 each\",\n" +
                    "                    \"productType\": \"Geneart\",\n" +
                    "                    \"productAttributes\": {\n" +
                    "                        \"id\": \"2022AAAMJF\",\n" +
                    "                        \"name\": \"2022AAAMJF\",\n" +
                    "                        \"processId\": 1,\n" +
                    "                        \"constructId\": \"22AAADCF\",\n" +
                    "                        \"projectDeliveryDays\": \"8\",\n" +
                    "                        \"geneDescription\": \"Construct Name: seq1\"\n" +
                    "                    }\n" +
                    "                }\n" +
                    "            },\n" +
                    "            {\n" +
                    "                \"lineNo\": 2,\n" +
                    "                \"quantity\": 1,\n" +
                    "                \"product\": {\n" +
                    "                    \"sku\": \"815030DE\",\n" +
                    "                    \"description\": \"GeneArt Strings(TM) DNA Fragment\",\n" +
                    "                    \"productSize\": \"1 each\",\n" +
                    "                    \"productType\": \"Geneart\",\n" +
                    "                    \"productAttributes\": {\n" +
                    "                        \"id\": \"2022AAAMJF\",\n" +
                    "                        \"name\": \"2022AAAMJF\",\n" +
                    "                        \"processId\": 2,\n" +
                    "                        \"constructId\": \"22AAADDF\",\n" +
                    "                        \"projectDeliveryDays\": \"8\",\n" +
                    "                        \"geneDescription\": \"Construct Name: seq2\"\n" +
                    "                    }\n" +
                    "                }\n" +
                    "            }\n" +
                    "        ]\n" +
                    "    }\n" +
                    "}");
            osw.flush();
            osw.close();
            os.close();

            BufferedReader br = null;
            if (con.getResponseCode() == 200) {
                br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String strCurrentLine;
                while ((strCurrentLine = br.readLine()) != null) {
                    System.out.println("Current line of data"+strCurrentLine);
                }
            } else {
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                String strCurrentLine;
                while ((strCurrentLine = br.readLine()) != null) {
                    System.out.println("current line of error"+strCurrentLine);
                }
            }

           // println("Response code found was" + con.getBody())
            System.out.println("Response found was:" + con.getInputStream().toString())

            String response = bufferedreading(con)

            System.out.println("Resposne found in Parsed String"+response)

            JSONObject myResponse = new JSONObject(response)
            System.out.println("Message found in the datajackson"+myResponse.getString("message"))


            ObjectMapper objectMapper = new ObjectMapper();
            String json = br.toString()
            objectMapper.configure(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE, false)
            JsonNode jsonNode = objectMapper.readTree(json);



            String color = jsonNode.get("cartId").asText()
            System.out.println("Cart id found from tree node"+color)



            Map<String, Object> map = objectMapper.readValue(json, new TypeReference<Map<String,Object>>(){});

            System.out.println("Mapped data foudn in the object"+map)

            JSONObject jsonObject = new JSONObject(br);

            JsonNode root = objectMapper.readTree(jsonObject)

            System.out.println("datafound at the root : " + root);
            JsonNode nameNode = root.path("shoppingCart");
           // if (!nameNode.isMissingNode()) {        // if "name" node is exist
                System.out.println("cartId found in direct : " + nameNode.path("cartId").asText());
                //  System.out.println("middleName : " + nameNode.path("middle").asText());
                //System.out.println("lastName : " + nameNode.path("last").asText());
          //  }
            return con.getInputStream();

    } catch (MalformedURLException e) {
        e.printStackTrace();
    }

}
    @Step("For username {2} and for catalognumber {5} result")
    public String parseAPIaddtoCart(String apiurl, String userName, String scid, String jsonBody, String catalogNumber, String countrycode){


        String https_url = apiurl;
        URL url;
        try {

            url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
            con.setRequestMethod("POST")

            //con.setRequestProperty("userName", userName)
            con.setRequestProperty("languageCode", "en")
            /*con.setRequestProperty("countryCode", countrycode)
            con.setRequestProperty("scid", scid)
            con.setRequestProperty("newCart", "true") */
            con.setRequestProperty("Content-Type", "application/json")
            con.setDoOutput(true)
            OutputStream os = con.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
            osw.write("{\n" +
                    "    \"userName\": \"cart.us@test.com\",\n" +
                    "    \"createNewCart\": true,\n" +
                    "    \"cartRequest\": {\n" +
                    "        \"lineItems\": [\n" +
                    "            {\n" +
                    "                \"lineNo\": 1,\n" +
                    "                \"quantity\": 1,\n" +
                    "                \"product\": {\n" +
                    "                    \"sku\": \"815020DE\",\n" +
                    "                    \"description\": \"GeneArt Strings(TM) DNA Fragment\",\n" +
                    "                    \"productSize\": \"1 each\",\n" +
                    "                    \"productType\": \"Geneart\",\n" +
                    "                    \"productAttributes\": {\n" +
                    "                        \"id\": \"2022AAAMJF\",\n" +
                    "                        \"name\": \"2022AAAMJF\",\n" +
                    "                        \"processId\": 1,\n" +
                    "                        \"constructId\": \"22AAADCF\",\n" +
                    "                        \"projectDeliveryDays\": \"8\",\n" +
                    "                        \"geneDescription\": \"Construct Name: seq1\"\n" +
                    "                    }\n" +
                    "                }\n" +
                    "            },\n" +
                    "            {\n" +
                    "                \"lineNo\": 2,\n" +
                    "                \"quantity\": 1,\n" +
                    "                \"product\": {\n" +
                    "                    \"sku\": \"815030DE\",\n" +
                    "                    \"description\": \"GeneArt Strings(TM) DNA Fragment\",\n" +
                    "                    \"productSize\": \"1 each\",\n" +
                    "                    \"productType\": \"Geneart\",\n" +
                    "                    \"productAttributes\": {\n" +
                    "                        \"id\": \"2022AAAMJF\",\n" +
                    "                        \"name\": \"2022AAAMJF\",\n" +
                    "                        \"processId\": 2,\n" +
                    "                        \"constructId\": \"22AAADDF\",\n" +
                    "                        \"projectDeliveryDays\": \"8\",\n" +
                    "                        \"geneDescription\": \"Construct Name: seq2\"\n" +
                    "                    }\n" +
                    "                }\n" +
                    "            }\n" +
                    "        ]\n" +
                    "    }\n" +
                    "}");
            osw.flush();
            osw.close();
            os.close();

            println("Response code found was"+con.getResponseCode())


          StringBuffer resposne = bufferedreading(con);
         //   String parsed_string = resposne.toString()
       //     println(resposne.toString())

            JSONObject jsonObject = new JSONObject(con);
             ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(jsonObject.toString())

            JsonNode nameNode = root.path("shoppingCart");
            if (!nameNode.isMissingNode()) {        // if "name" node is exist
                System.out.println("cartId found in direct : " + nameNode.path("cartId").asText());
              //  System.out.println("middleName : " + nameNode.path("middle").asText());
                //System.out.println("lastName : " + nameNode.path("last").asText());
            }

            String cartid = root.getAt("message")
                    //getJSONObject("data").getJSONObject("shoppingCart").getString("cartId");
            System.out.println("Cartid found after parsing"+cartid)

            Map<String,String> map = new HashMap<String,String>();
            String[] entries = parsed_string.split(",");
            for (String entry : entries) {
                String[] keyValue = entry.split(":");
                map.put(keyValue[0],keyValue[1]);
                System.out.println("Parsed string looks like this"+keyValue)
            }



            if (map.containsKey("cartId")) {
                System.out.println("cart id found in the"+map.get("cartId"))
                return map.values("cartID");
            }

            JSONObject myResponse = new JSONObject(con)
            //JSONPObject jsonpObject = new JSONPObject(resposne.toString())
            JSONObject compose = (JSONObject) myResponse.getJSONObject("message");
            System.out.println("data: " + compose);

            JSONArray jsonArray = myResponse.getJSONArray("data")
            System.out.println("data: foudn in data array" + jsonArray);


            JSONArray soundex = (JSONArray) compose.getJSONArray("shoppingCart");
           // JSONObject secObject = (JSONObject) jsonChildArray.get("shoppingCart");
           // String cartid = myResponse.getString("cartId")
            Iterator itr = soundex.iterator();

            while (itr.hasNext()) {

                Object slide = itr.next();
                JSONObject jsonObject2 = (JSONObject) slide;
                JSONObject info = (JSONObject) jsonObject2.get("cartId");

                String date_of_birth = (String) info.get("cartId");
                String name_id = (String) info.get("userId");

                System.out.println("\t\tCart id found : " + date_of_birth);
                System.out.println("\t\tUser id found in " + name_id);
            }

            System.out.println("cart id foudn after"+secObject)
            return print_content(con)
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Step("For username {2} and for catalognumber {5} result")
    public String parseAPICheckout(String apiurl, String userName, String scid, String jsonBody, String catalogNumber, String countrycode){


        String https_url = "https://tfcommerce-api-eks.cloudqa.ezconsult.net/api/store/core/checkout/initiate";
        URL url;
        try {

            url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
            con.setRequestMethod("POST")

            con.setRequestProperty("userName", userName)
            con.setRequestProperty("userid", scid)
           // con.setRequestProperty("languageCode", "en")
            /*con.setRequestProperty("countryCode", countrycode)
            con.setRequestProperty("scid", scid)
            con.setRequestProperty("newCart", "true") */
            con.setRequestProperty("Content-Type", "application/json")
            con.setDoOutput(true)
            OutputStream os = con.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
            osw.write("{\n" +
                    "  \"cartId\": 29838721,\n" +
                    "  \"cartType\": \"TF\",\n" +
                    "  \"userName\": \"cart.us@test.com\",\n" +
                    "  \"userId\": \"" +
                    userName +
                    "  \"orderPaymentInformation\": {\n" +
                    "    \"paymentMethod\": \"PURCHASE_ORDER\",\n" +
                    "    \"paymentNumber\": \"12345\"\n" +
                    "  }\n" +
                    "}");
            osw.flush();
            osw.close();
            os.close();

            println("Response code found was"+con.getResponseCode())


            StringBuffer resposne = bufferedreading(con);
            JSONObject myResponse = new JSONObject(resposne.toString())
            String orderNumber = myResponse.getString("orderNumber")
            System.out.println("Ordernumber foudn after"+orderNumber)

            return print_content(con)

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void print_https_cert(HttpsURLConnection con){

        if(con!=null){

            try {

                println("Response Code : " + con.getResponseCode());
//                println("Cipher Suite : " + con.getCipherSuite());
                println("\n");


            } catch (SSLPeerUnverifiedException e) {
                e.printStackTrace();
            } catch (IOException e){
                e.printStackTrace();
            }

        }

    }

    private void print_content(HttpsURLConnection con){
        if(con!=null){

            try {

                println("****** Content of the URL ********");
                BufferedReader br =
                        new BufferedReader(
                                new InputStreamReader(con.getInputStream()));

                String input;

                while ((input = br.readLine()) != null){
                    println(input);
                }
                br.close();

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }

    def bufferedreading(HttpsURLConnection url) throws IOException {

        BufferedReader input = new BufferedReader(
                new InputStreamReader(url.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = input.readLine()) != null)
        {
            inputLine = inputLine.replace("\\[", "").replace("\\]", "")
            inputLine = inputLine.replaceAll("<.*?>|\u00a0/^\\s+/,\"\"", "")
            response.append(inputLine)
        }
        input.close();

        return response;


    }



}

