package com.tfs.pages

import org.json.JSONObject

import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLPeerUnverifiedException
import java.nio.charset.StandardCharsets

public class HttpsClient_modified {



    public String returnToken(String username, String password)
    {
        String https_url = "https://ezconsult-strapi-staging.azurefd.net/auth/local";
       // String urlParameters  = "identifier="+username+"password="+password;
        String urlParameters  = "identifier="+username+"&password="+password;
        byte[] postData = urlParameters.getBytes(StandardCharsets.UTF_8 );
        int postDataLength = postData.length;

        URL url;
        try {

            url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection)url.openConnection();

            con.setDoOutput(true);
            con.setInstanceFollowRedirects(false);
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            con.setRequestProperty("charset", "utf-8");
            con.setRequestProperty("Content-Length", Integer.toString(postDataLength));
            con.setUseCaches(false);
           DataOutputStream wr = new DataOutputStream(con.getOutputStream())
                wr.write(postData);


            StringBuffer resposne = bufferedreading(con);
            JSONObject myResponse = new JSONObject(resposne.toString())

            System.out.println("API OUTPUT:"+myResponse)
            String token = myResponse.getString("jwt")
            System.out.println("Token found"+token)

            println("Response code found was"+con.getResponseCode())

            return token


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    public String getConsulationid(String username, String password)
    {

        try {
            String https_url = "https://ezvaxuat.azurewebsites.net/query";
            URL url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            //urlConnection = (HttpURLConnection) url.openConnection();
            con.setReadTimeout(10000 /* milliseconds */);
            con.setConnectTimeout(15000 /* milliseconds */);
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setRequestProperty("authorization", "Bearer "+returnToken("karthikpatient@mailinator.com", "Qwer1234\$"));
            con.setRequestProperty("Content-Type", "application/json");


            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes("{\"query\":\"{\\r\\n    consultations(input:{\\r\\n      doctorid: 2576619,\\r\\n      patientid: 2576434\\r\\n  }){\\r\\n    consultations{\\r\\n        id,\\r\\n        consultation_fee,\\r\\n        consultation_status\\r\\n      }\\r\\n    }   \\r\\n}\",\"variables\":{}}");
            wr.flush();
            wr.close();

            int rc = con.getResponseCode();

            System.out.println("Api response found for GET_CONSULTATION_ID"+print_content(con));
         // List<String> consultationids = con.getAt("id")
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }




}




    public String parseAPI(String apiurl, String userName, String scid, String jsonBody, String catalogNumber, String countrycode){



        String https_url = "https://ezconsult-strapi-staging.azurefd.net/consultations/143171";
       // String https_url = apiurl;
        URL url;
        try {

            url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
            con.setRequestMethod("PUT")

                    con.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2NTkxNzMzMjMsImlhdCI6MTY1OTA4NjkyMywiaWQiOjI1NzQ1NzksInJpZ2h0cyI6bnVsbCwicm9sZSI6IkF1dGhlbnRpY2F0ZWQiLCJ1c2VybmFtZSI6InRlc3Rkb2N0b3JAbWFpbGluYXRvci5jb20ifQ.zPo4IvPsVmUVXC1qgB_OX7XCo1MDqZnPZlgRKp7D7tw")

            con.setRequestProperty("Content-Type", "application/json")
            con.setDoOutput(true)
            con.setDoInput(true)
            OutputStream os = con.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
            osw.write("{\n" +
                    "\n" +
                    "\"patient_id\": \"2576434\",\n" +
                    "\n" +
                    "\"doctor_id\": \"2574579\",\n" +
                    "\n" +
                    "\"consultation_status\": \"doctor confirmed\",\n" +
                    "\n" +
                    "\"chatsession_id\": \"62971513cb99d8000b538366\",\n" +
                    "\n" +
                    "\"freeConsultation\": false\n" +
                    "\n" +
                    "}");
            osw.flush();
            osw.close();
            os.close();

            println("Response code found was"+con.getResponseCode())

            return print_content(con)


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public String fetchResponse(String apiurl, String customercode, String salesorg, String shipToCustomer, String catalogNumber, String countrycode){

        String https_url = apiurl;
        // String https_url = apiurl;
        URL url;
        try {

            url = new URL(https_url);
            HttpsURLConnection con = (HttpsURLConnection)url.openConnection();
            con.setRequestMethod("POST")

            con.setRequestProperty("authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MjIwLCJyb2xlIjoiUk9PVCBBZG1pbiIsInVzZXJuYW1lIjoic3VwZXJ1c2VyIiwicmlnaHRzIjpbeyJ2YWx1ZSI6W3sic2hpcFRvQ29kZSI6WyJhbGwiXSwiY3VzdG9tZXJDb2RlIjoiMDAzMDAxNDkyNyJ9LHsic2hpcFRvQ29kZSI6WyIwMDcwMDE3MDExIl0sImN1c3RvbWVyQ29kZSI6IjAwMzAwMTQxNDAifV19LHsidmFsdWUiOlt7InNoaXBUb0NvZGUiOlsiMDA3MDEwMDAwMCJdLCJjdXN0b21lckNvZGUiOiIwMDMwMDM4NTAxIn1dfV0sInNhbGVzT3JnIjpbIjI1MDAiLCIyODAwIl0sIkFVVEhfVE9LRU4iOiJ3OXhwQWFCRFlRIiwiaWF0IjoxNTg5MTgxODAyLCJleHAiOjE3NTMxMTY4NDJ9.ogQ2LariDHaRl1CkgBR1yQh_RYSCllWJYo2xOwD3BHU")

            con.setRequestProperty("Content-Type", "application/json")
            con.setDoOutput(true)
            con.setDoInput(true)
            OutputStream os = con.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
            osw.write("{\n" +
                    "    \"query\": \"query {\\n  materialsWithMeta(\\n    customer: \\\"" +
                    customercode +
                    "\\n    shipToCustomer: \\+" +
                    shipToCustomer +
                    "\\n    salesOrganisation: \\\"+" +
                    salesorg +
                    "\\n    plants: []\\n    first: 111\\n    after: 0\\n    cached: false\\n    orderBy: \\\"materialDescription_asc\\\"\\n  ) {\\n    rawMetaData {\\n      type\\n      count\\n      __typename\\n    }\\n    materials {\\n      principalCode\\n      principalName\\n      materialNumber\\n      materialDescription\\n      therapeuticClass\\n      itemBrand\\n      governmentMaterialCode\\n      defaultMaterialDescription\\n      oldMaterialCode\\n      materialGroup4\\n      materialGroup2\\n      taxClassification\\n      unitOfMeasurement\\n      itemRegistrationNumber\\n      genericMaterialName\\n      language\\n      taxM1\\n      taxes\\n      isSampleMaterial\\n      hidePrice\\n      hasValidTenderContract\\n      hasMandatoryTenderContract\\n      isFOCMaterial\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\"\n" +
                    "}");
            osw.flush();
            osw.close();
            os.close();

            println("Response code found was"+con.getResponseCode())

            return print_content(con)


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    def bufferedreading(HttpsURLConnection url) throws IOException {

        BufferedReader input = new BufferedReader(
                new InputStreamReader(url.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = input.readLine()) != null)
        {
            inputLine = inputLine.replace("\\[", "").replace("\\]", "")
            inputLine = inputLine.replaceAll("<.*?>|\u00a0/^\\s+/,\"\"", "")
            response.append(inputLine)
        }
        input.close();

        return response;


    }

    private void print_content(HttpsURLConnection con){
        if(con!=null){

            try {

                println("****** Content of the URL ********");
                BufferedReader br =
                        new BufferedReader(
                                new InputStreamReader(con.getInputStream()));

                String input;

                while ((input = br.readLine()) != null){
                    println(input);
                }
                br.close();

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }



}

