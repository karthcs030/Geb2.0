package com.tfs.pages

import com.tfs.common.configdataFetcher
import com.tfs.common.webDriverLibrary
import geb.Browser
import io.qameta.allure.Step
import org.openqa.selenium.By
import org.openqa.selenium.Cookie
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Actions

//import BaseGebSpec

//import geb.Page

class LoginPage extends webDriverLibrary {
    static Browser browser

    LoginPage(Browser browser){
        this.browser=browser
    }

    @Step("Login to EZHealth with valid username and password")
    def logintoEZHealth(String username, String password)
    {
        waitFor("username")
        typeText("username", username)
        waitFor("password")
        typeText("password", password)
        waitForClickable("login")
        click("login")
    }

    @Step("Login to eZRX with valid username and password")
    def logintoeZRX(String username, String password)
    {

        waitForClickable("login")
        click("login")


        //waitForClickable("loginwithSSO")
        //click("loginwithSSO")
        Thread.sleep(10000)
        waitFor("username")
        typeText("username", username)
//        waitForClickable("usernamenext")
  //      click("usernamenext")
        waitFor("password")
        typeText("password", password)
        waitForClickable("Signin")
        Thread.sleep(10000)
        click("Signin")
    }

    @Step("Login to eZRx Korea with valid username and password")
    def logineZRxKoreaUAT(String username, String password){
        waitForTimePeriod(1000)
        waitForClickable("eZRxKoreaUsername")
        typeText("eZRxKoreaUsername", username)
        waitForTimePeriod(1000)
        waitForClickable("eZRxKoreaPassword")
        typeText("eZRxKoreaPassword", password)
        waitForTimePeriod(1000)
        waitForClickable("eZRxKoreaLogin")
        click("eZRxKoreaLogin")
        waitForTimePeriod(1000)
    }

    @Step("Login to eZRX with valid username and password")
    def logintoeZRXdev(String username, String password)
    {

        waitForClickable("login")
        click("login")


        waitForClickable("loginwithSSO")
        click("loginwithSSO")
        Thread.sleep(10000)
        waitFor("username")
        typeText("username", username)
        waitForClickable("usernamenext")
              click("usernamenext")
        waitFor("password")
        typeText("password", password)
        waitForClickable("login")
        Thread.sleep(10000)
        click("login")
    }

    def logintoeZRXprod(String username, String password)
    {

        waitForClickable("login")
        click("login")


        Thread.sleep(10000)
        waitFor("username")
        typeText("username", username)
       // waitForClickable("usernamenext")
        //click("usernamenext")
        waitFor("password")
        typeText("password", password)
        waitForClickable("login")
        Thread.sleep(10000)
        click("login")
    }

    @Step("wait for error message to appear")
    def seeErrorMsg()
    {
        waitFor("errormsg")
        readText("errormsg")
        screenshot(browser.driver)

    }

    @Step("Logout from EZhealth")
    def logout()
    {
        scrolltop()
        waitFor("name")
        click("name")
        waitFor("logout")
        click("logout")
        waitFor("username")
    }

    def ezrxLogout()
    {
        waitForClickable("userprofile")
        mouseOver("userprofile", browser.driver)
        waitForClickable("ezrxlogout")
        jsclick("ezrxlogout")
        waitForClickable("login")
    }

    def loginasSalesrep(String salesrep)
    {
        waitForClickable("userprofile")
        mouseOver("userprofile", browser.driver)
        waitForClickable("loginonbehalf")
        Thread.sleep(2000)
        click("loginonbehalf")
        waitForClickable("enterad")
        typeText("enterad", salesrep)
        waitForClickable("loginassalesrep")
        click("loginassalesrep")
       Thread.sleep(5000)
    }

    def changelanguage()
    {
        waitForClickable("flag")
        Thread.sleep(5000)
        click("flag")
        waitForClickable("Kh")
        click("Kh")
        scrolltop()
        Thread.sleep(5000)
        waitForClickable("flag2")
        click("flag2")
        waitForClickable("en")
        click("en")
    }





}

