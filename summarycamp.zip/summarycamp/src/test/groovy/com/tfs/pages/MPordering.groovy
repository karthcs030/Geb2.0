package com.tfs.pages

import com.tfs.common.webDriverLibrary
import geb.Browser

//import BaseGebSpec

//import geb.Page

class MPordering extends webDriverLibrary{
    static Browser browser

    MPordering(Browser browser){
        this.browser=browser
    }

   def navigatetoMarketplace()
   {
       waitForClickable("marketplace")
       click("marketplace")
       waitForClickable("covidessentials")


   }

    def allcatrgoriesitemstocart()
    {
        waitForClickable("covidessentials")
        click("covidessentials")
        addSingleitemtocart()
        waitForClickable("prescriptionpharma")
        click("prescriptionpharma")
        addSingleitemtocart()
        waitForClickable("health")
        click("health")
        addSingleitemtocart()
        waitForClickable("personalcare")
        click("personalcare")
        addSingleitemtocart()

        waitForClickable("skincare")
        click("skincare")
        addSingleitemtocart()

        waitForClickable("medicalsupplies")
        click("medicalsupplies")
        addSingleitemtocart()

        waitForClickable("medicalsupplies")
        click("medicalsupplies")
        addSingleitemtocart()
    }

    def  addSingleitemtocart()
    {
        Thread.sleep(5000)
        int elesize = clickifvisible("addtocartimg")
        if(elesize>0) {
            waitFor("itemtocart")
        }
        navigateback()
    }

    def carvalidations()
    {
        scrolltop()
        waitForClickable("carticon")
        click("carticon")
        waitForClickable("deleteicon")
        click("deleteicon")
        Thread.sleep(10000)
        waitForClickable("viewcart")
        click("viewcart")
        waitFor("cartitems")
    }

    def cartsummary()
    {
        waitFor("cartitems")
        waitForClickable("plusign")
        clickifvisible("plusign")
        checkifVisible("promocoode")
        waitForClickable("checkout")
        click("checkout")
        waitFor("poreferenceinput")
    }

    def cartreview()
    {
        waitForClickable("poreferenceinput")
        typeText("poreferenceinput", "1234567890")
        waitForClickable("deliveryinstructions")
        typeText("deliveryinstructions", "Test order please don't process")
        waitForClickable("placeorder")

    }

    def placeorder()
    {
        waitForClickable("placeorder")
        click("placeorder")
        waitFor("thankyou")
        waitFor("confirmationmessage")
    }
}

