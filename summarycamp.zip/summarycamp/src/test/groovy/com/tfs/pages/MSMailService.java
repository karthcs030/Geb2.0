package com.tfs.pages;



import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.PropertySet;
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion;
import microsoft.exchange.webservices.data.core.enumeration.property.BasePropertySet;
import microsoft.exchange.webservices.data.core.enumeration.property.BodyType;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.enumeration.search.LogicalOperator;
//import microsoft.exchange.webservices.data.core.service.folder.Folder;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.schema.ItemSchema;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.property.complex.FileAttachment;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.ItemView;
import microsoft.exchange.webservices.data.core.service.folder.Folder;
import microsoft.exchange.webservices.data.search.filter.SearchFilter;
//import org.springframework.util.CollectionUtils;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;


public class MSMailService {


    private static ExchangeService createConnection() throws Exception {
        String email = "ITQASupport@ezconsult.com";
        String password = "ITqa851!";
        ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
        ExchangeCredentials credentials = new WebCredentials(email, password, "apac.thermo.com");
        service.setUrl(new URI("https://outlook.office365.com/EWS/Exchange.asmx"));
        service.setCredentials(credentials);
        System.out.println("Connection sucessfully created");
        return service;
    }

 /*   void read(ExchangeService service){
        Folder folder = Folder.bind(service, WellKnownFolderName.Inbox);
        FindItemsResults<Item> results = service.findItems(folder.getId(), new ItemView(10))
        for (Item item : results) {
            EmailMessage emailMessage = EmailMessage.bind(service, item.getId())
            println("Sender: ${emailMessage.getSender()}")
            println("Subject: ${emailMessage.getSubject()}")
        }
    }*/

    private static void readAttachmentEmail(ExchangeService service) throws Exception {
        // Bind to the Inbox.
        Folder inbox = Folder.bind(service, WellKnownFolderName.Inbox);
        // set number of items you want to retrieve
        ItemView view = new ItemView(5);
        PropertySet itemPropertySet = new PropertySet(BasePropertySet.FirstClassProperties);
        itemPropertySet.setRequestedBodyType(BodyType.Text);


        List<SearchFilter> searchFilterCollection = new ArrayList<>();
        // flag to pick only email which contains attachments
        searchFilterCollection.add(new SearchFilter.IsEqualTo(ItemSchema.HasAttachments, Boolean.FALSE));
        searchFilterCollection.add(new SearchFilter.ContainsSubstring(ItemSchema.Subject, "88294507"));
        SearchFilter finalSearchFilter = new SearchFilter.SearchFilterCollection(LogicalOperator.And, searchFilterCollection);
        ArrayList<Item> items = service.findItems(inbox.getId(), finalSearchFilter, view).getItems();



       // if (!CollectionUtils.isEmpty(items)) {
            Item item = (Item) items.get(0);
            item.load(itemPropertySet);

            System.out.println("id==========" + item.getDateTimeReceived());
            System.out.println("sub==========" + item.getSubject());
        EmailMessage emailbody = EmailMessage.bind(service, item.getId(), new PropertySet(ItemSchema.Body));
            System.out.println("Email Body==========" + item.getBody().toString());
            EmailMessage message = EmailMessage.bind(service, item.getId(), new PropertySet(ItemSchema.Attachments));
            FileAttachment attachment = (FileAttachment) message.getAttachments().getItems().get(0);
            attachment.load(" < attachment save directory > " + attachment.getName());
       // }

    }
}
