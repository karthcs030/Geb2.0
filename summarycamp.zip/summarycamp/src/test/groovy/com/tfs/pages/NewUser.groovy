package com.tfs.pages

import com.tfs.common.configdataFetcher
import com.tfs.common.webDriverLibrary
import geb.Browser
import io.qameta.allure.Step
import org.openqa.selenium.By
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Actions
import org.openqa.selenium.support.ui.ExpectedConditions
import org.openqa.selenium.support.ui.Select

class NewUser extends webDriverLibrary {

    static Browser browser

    String ItemName = "Sign In"
    Random r = new Random()
    String password = "Thermo@123"

    NewUser(Browser browser) {
        this.browser = browser
    }



    }




