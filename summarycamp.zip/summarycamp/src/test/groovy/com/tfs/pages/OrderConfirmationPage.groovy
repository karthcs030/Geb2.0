package com.tfs.pages

import com.tfs.common.webDriverLibrary
import geb.Browser

//import BaseGebSpec
import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.Keys
import org.openqa.selenium.WebElement
import org.testng.Assert

//import geb.Page

class OrderConfirmationPage extends webDriverLibrary{
    static Browser browser

    OrderConfirmationPage(Browser browser){
        this.browser=browser
    }

    def selectShiptoDynamic(String salesorg, String customerCode, String  ShipTo)
    {
        Thread.sleep(10000)
        waitForClickable("selectshipto")
        click("selectshipto")
        waitForClickable("salesorg")
        browser.driver.navigate().refresh()
        waitForClickable("selectshipto")
        click("selectshipto")
        waitForClickable("salesorg")
        Thread.sleep(10000)
        click("salesorg")
        Thread.sleep(3000)
        WebElement sales_org = browser.getDriver().findElement(By.xpath("//*[@name='"+salesorg+"']"))
        jsclick(sales_org, browser.getDriver())
      //  waitForClickable("salesorgidentifier"+salesorg+"\"]")
        //click("salesorgidentifier"+salesorg+"\"]")
        Thread.sleep(10000)
        waitForClickable("selectcustomercode")
        click("selectcustomercode")
        //waitForClickable("customercodeinput")
        //actionClick("customercodeinput")
        WebElement currentElement = browser.driver.switchTo().activeElement();
        //Thread.sleep(2000)
        currentElement.sendKeys(customerCode)
        Thread.sleep(7000)
        currentElement.sendKeys(Keys.DOWN, Keys.RETURN);
        Thread.sleep(10000)
        waitForClickable("shipcode")
        click("shipcode")


        WebElement currentElement2 = browser.driver.switchTo().activeElement();

        currentElement2.sendKeys(ShipTo)
        Thread.sleep(7000)
        currentElement2.sendKeys(Keys.DOWN, Keys.RETURN);

        waitForClickable("saveshipto")
        click("saveshipto")
        waitFor("selectedshipto")
        String selectedship = readText("selectedshipto")
        return selectedship

    }

    def selectShiptoDynamicVN(String salesorg, String customerCode, String  ShipTo)
    {
        Thread.sleep(10000)
        waitForClickable("selectshipto")
        click("selectshipto")
        waitForClickable("salesorg")
        browser.driver.navigate().refresh()
        waitForClickable("selectshipto")
        click("selectshipto")
        waitForClickable("salesorg")
        Thread.sleep(10000)
        click("salesorg")
        Thread.sleep(3000)
        WebElement sales_org = browser.getDriver().findElement(By.xpath("//li[contains(text(), '"+salesorg+"')]"))
        jsclick(sales_org, browser.getDriver())
        //  waitForClickable("salesorgidentifier"+salesorg+"\"]")
        //click("salesorgidentifier"+salesorg+"\"]")
        Thread.sleep(10000)
        waitForClickable("selectcustomercode")
        click("selectcustomercode")
        //waitForClickable("customercodeinput")
        //actionClick("customercodeinput")
        WebElement currentElement = browser.driver.switchTo().activeElement();
        //Thread.sleep(2000)
        currentElement.sendKeys(customerCode)
        Thread.sleep(7000)
        currentElement.sendKeys(Keys.DOWN, Keys.RETURN);
        Thread.sleep(10000)
        waitForClickable("shipcode")
        click("shipcode")


        WebElement currentElement2 = browser.driver.switchTo().activeElement();

        currentElement2.sendKeys(ShipTo)
        Thread.sleep(7000)
        currentElement2.sendKeys(Keys.DOWN, Keys.RETURN);

        waitForClickable("saveshipto")
        click("saveshipto")
        waitFor("selectedshipto")
        String selectedship = readText("selectedshipto")
        return selectedship

    }

   def selectShiptoByCode(String shipcode)
   {
       Thread.sleep(10000)
       waitForClickable("selectshipto")
       click("selectshipto")
       Thread.sleep(5000)
      waitForClickable("selectcustomercode")
      click("selectcustomercode")
       //waitForClickable("customercodeinput")
       //actionClick("customercodeinput")
       WebElement currentElement = browser.driver.switchTo().activeElement();
       //Thread.sleep(2000)
       currentElement.sendKeys(shipcode)
       Thread.sleep(7000)
     // waitFor("customercode2")
//       actionClick("customercode2")

       currentElement.sendKeys(Keys.DOWN, Keys.RETURN);

       //typeText("customercodeinput", shipcode)
       //waitForClickable("customercode")
       //actionClick("customercode")
       waitForClickable("saveshipto")
       click("saveshipto")
       waitFor("selectedshipto")
       String selectedship = readText("selectedshipto")
       return selectedship
   }


  def selectShipto()
  {

     Thread.sleep(10000)
      waitForClickable("selectshipto")
      click("selectshipto")
      waitForClickable("selectcustomercode")
      click("selectcustomercode")
      waitForClickable("customercode")
      click("customercode")
      waitForClickable("saveshipto")
      click("saveshipto")
      waitFor("selectedshipto")
      String selectedship = readText("selectedshipto")
      return selectedship
  }

    def selectShiptowithSalesOrg()
    {

        Thread.sleep(10000)
        waitForClickable("selectshipto")
        click("selectshipto")
        Thread.sleep(5000)
        waitForClickable("salesorg")
        click("salesorg")
        Thread.sleep(10000)
        waitForClickable("salesorgname")
        click("salesorgname")

        waitForClickable("selectcustomercode")
        click("selectcustomercode")
        waitForClickable("customercode")
        click("customercode")
        waitForClickable("saveshipto")
        click("saveshipto")
        waitFor("selectedshipto")
        String selectedship = readText("selectedshipto")
        return selectedship
    }

    def selectCustomercodeandShipto(String customerCode, String ShipTo)
    {

        Thread.sleep(10000)
        waitForClickable("selectshipto")
        click("selectshipto")
        waitForClickable("salesorg")
        Thread.sleep(10000)
        waitForClickable("selectcustomercode")
        click("selectcustomercode")
        //waitForClickable("customercodeinput")
        //actionClick("customercodeinput")
        WebElement currentElement = browser.driver.switchTo().activeElement();
        //Thread.sleep(2000)
        currentElement.sendKeys(customerCode)
        Thread.sleep(7000)
        currentElement.sendKeys(Keys.DOWN, Keys.RETURN);
        Thread.sleep(10000)
        waitForClickable("shipcode")
        click("shipcode")


        WebElement currentElement2 = browser.driver.switchTo().activeElement();

        currentElement2.sendKeys(ShipTo)
        Thread.sleep(7000)
        currentElement2.sendKeys(Keys.DOWN, Keys.RETURN);

        waitForClickable("saveshipto")
        click("saveshipto")
        waitFor("selectedshipto")
        String selectedship = readText("selectedshipto")
        return selectedship

    }

    def addAdditonalInformation()
    {
        waitForClickable("createorder")
        click("createorder")
        waitForClickable("customporeference")
        String datetimestamp = dateTimeStamp()
        typeText("customporeference", datetimestamp)
        typeText("specialinstructions", "special instructions")
        typeText("referencenote", "reference note")
//        waitForClickable("deliverydate")
        scroll("specialinstructions")
        Thread.sleep(5000)
        waitForClickable("paymentterm")
        click("paymentterm")
        waitForClickable("selectpaymentterm")
        click("selectpaymentterm")
        typeText("contactperson", "cintact person")
        typeText("contactnumber", "1234567890")
        return  datetimestamp


    }

    def addAdditionalInfo(){
        waitForClickable("createorder")
        click("createorder")
        String datetimestamp = dateTimeStamp()
        try {
            waitForClickable("customporeference")

            typeText("customporeference", datetimestamp)
        }catch(Exception e){
            System.out.println("Customer PO Reference is not visible")
        }
        try {
            waitForClickable("specialinstructions")
            typeText("specialinstructions", "special instructions")
        }catch(Exception e){
            System.out.println("Special Instruction is not visible")
        }
        try {
            waitForClickable("referencenote")
            typeText("referencenote", "reference note")
        }catch(Exception e){
            System.out.println("Special Instruction is not visible")
        }
//        waitForClickable("deliverydate")
        scroll("specialinstructions")
        waitForTimePeriod(5000)
        try {
            waitForClickable("paymentterm")
            click("paymentterm")
        }catch(Exception e){
            System.out.println("Payment term is not visible")
        }
        try {
            waitForClickable("selectpaymentterm")
            click("selectpaymentterm")
        }catch(Exception e){
            System.out.println("Select Payment term is not visible")
        }
        try {
            waitForClickable("contactperson")
            typeText("contactperson", "contact person")
        }catch(Exception e){
            System.out.println("Contact Person is not visible")
        }
        try {
            waitForClickable("contactnumber")
            typeText("contactnumber", "contact person")
        }catch(Exception e){
            System.out.println("Contact Number is not visible")
        }
        return  datetimestamp
    }

    def addAdditonalInformationProd()
    {
        waitForClickable("createorder")
        click("createorder")
        waitForClickable("customporeference")
        String datetimestamp = dateTimeStamp()
        typeText("customporeference", datetimestamp)
        typeText("specialinstructions", "special instructions")
        typeText("referencenote", "reference note")
//        waitForClickable("deliverydate")
        scroll("specialinstructions")
        Thread.sleep(5000)
        waitForClickable("paymentterm")
        click("paymentterm")
        waitForClickable("selectpaymentterm")
        click("selectpaymentterm")
        typeText("contactperson", "cintact person")
       // typeText("contactnumber", "1234567890")
        return  datetimestamp


    }

    def additionalinfoTW()
    {
        waitForClickable("createorder")
        click("createorder")
        waitForClickable("customporeference")
        String datetimestamp = dateTimeStamp()
        typeText("customporeference", datetimestamp)
        waitForClickable("selectordertype")
        click("selectordertype")
        waitForClickable("sampletrial")
        click("sampletrial")
        typeText("specialinstructions", "special instructions")
        typeText("referencenote", "reference note")
        typeText("contactperson", "cintact person")
        typeText("contactnumber", "1234567890")
    }

    def addAdditonalInformationMY()
    {

        waitForClickable("createorder")
        scroll("placeanordertext")
        Thread.sleep(5000)
        click("createorder")
        waitForClickable("customporeference")
        String datetimestamp = dateTimeStamp()
        typeText("customporeference", datetimestamp)
        typeText("specialinstructions", "special instructions")
        return  datetimestamp


    }

    def checkforMinimumOrderValue()
    {

        waitForClickable("firstaddtocart")
        click("firstaddtocart")
        waitForClickable("submitorder")

        click("submitorder")
        waitFor("minimumorder")
        scroll("firstaddtocart")
        waitForClickable("overrideprice")
        Thread.sleep(10000)
        typeText("overrideprice", "101")
        Thread.sleep(10000)
        waitForClickable("submitorder")
        click("submitorder")
        waitFor("ordernumber")
    }

    def priceOverrirde()
    {
        scroll("firstaddtocart")
        waitForClickable("overrideprice")
        Thread.sleep(10000)
        typeText("overrideprice", "101")
        Thread.sleep(10000)
    }

    def chooseTemplate()
    {
        waitForClickable("orders")
        click("orders")
        waitForClickable("createneworder")
        click("createneworder")
        waitFor("createorderfromtemplate")
        waitForClickable("createorderfromtemplate")
        click("createorderfromtemplate")
        waitForClickable("arrowndown")
        click("arrowndown")
        waitForClickable("selecttemplate")
        click("selecttemplate")

    }

    def addBundlesFromAddbundlesTab(){

            scrolltop()
            waitForClickable("addBundlesTab")
            click("addBundlesTab")
            waitForClickable("expandRow1")
            click("expandRow1")
            waitForClickable("addItem")
            clickMultipleElements("addItem")
            waitForClickable("bundleaddtocart")
            click("bundleaddtocart")
//            waitForTimePeriod("2000")

    }
    def addItemsToCartFromAddMaterials(){

            waitForClickable("plusquanity1")
            for(int i = 0; i <3;i++)
            {
                click("plusquanity1")
                Thread.sleep(1000)
            }
            waitForClickable("plusquanity2")
            click("plusquanity2")
            waitForClickable("addtocart1")
            click("addtocart1")
            waitForTimePeriod(1000)
            waitForClickable("addtocart2")
            click("addtocart2")
            waitForTimePeriod(1000)
            waitForClickable("addtocart3")
            click("addtocart3")
            waitForTimePeriod(1000)

    }

    def clickOnSubmitOrderBtn()
    {

            waitForTimePeriod(10000)
            waitForClickable("submitorder")
            jsclick("submitorder")

    }
    def clickOnOrderHistoryUnderOrdersTab(){
        try {
            waitForClickable("orders")
            mouseOver("orders", browser.driver)
            waitForClickable("orderHistoryUnderOrdersTab")
            click("orderHistoryUnderOrdersTab")
            waitForTimePeriod(5000)
            waitForClickable("vieworder")
            click("vieworder")
            waitForTimePeriod(5000)
            mouseOver("OrderUnderOrderHistory", browser.driver)
        }catch(Exception e){
            e.printStackTrace()
        }
    }

    def addItemstoCart()
    {
        waitForClickable("plusquanity1")
        for(int i = 0; i <3;i++)
        {
            click("plusquanity1")
            Thread.sleep(1000)
        }
        waitForClickable("plusquanity2")
        click("plusquanity2")
//        click("plusquanity3")

        waitForClickable("addtocart1")
        click("addtocart1")
        Thread.sleep(1000)
        waitForClickable("addtocart2")
        click("addtocart2")
        Thread.sleep(1000)
        waitForClickable("addtocart3")
        click("addtocart3")
        Thread.sleep(1000)
        waitForClickable("submitorder")
        click("submitorder")
        waitForClickable("orderhistory")
        click("orderhistory")

    }

    def addItemstoCartTW()
    {
        waitForClickable("plusquanity1")
        for(int i = 0; i <3;i++)
        {
            click("plusquanity1")
            Thread.sleep(1000)
        }
        waitForClickable("plusquanity2")
        click("plusquanity2")
//        click("plusquanity3")

//        waitForClickable("addtocart1")
        clickMultipleElements("addtocartnotdisabled")

      //  click("addtocart1")
        Thread.sleep(1000)
       // waitForClickable("addtocart2")
        click("addtocart2")
        Thread.sleep(1000)

        waitForClickable("submitorder")
        click("submitorder")
        waitForClickable("orderhistory")
        click("orderhistory")

    }

    def addItemstoCartPH()
    {
        waitForClickable("plusquanity7")
        for(int i = 0; i <3;i++)
        {
            click("plusquanity7")
            Thread.sleep(1000)
        }
        waitForClickable("plusquanity8")
        click("plusquanity8")
//        click("plusquanity3")

        waitForClickable("addtocart7")
        click("addtocart7")
        Thread.sleep(1000)
        waitForClickable("addtocart8")
        click("addtocart8")
        Thread.sleep(1000)
        waitForClickable("addtocart9")
        click("addtocart9")
        Thread.sleep(1000)
        waitForClickable("submitorder")
        click("submitorder")
        waitForClickable("orderhistory")
        submiteZRxSurvery()
        Thread.sleep(5000)
        click("orderhistory")

    }

    def orderHistoryVerification(String Ponumber)
    {

        Thread.sleep(60000)
        browser.driver.navigate().refresh()
        waitForClickable("custompo")
        typeText("custompo", Ponumber)
        println("PO Number entered for order"+Ponumber)
        waitFor("resultrow")
      //  checkifVisible("poreference")
        checkifVisible("orderdate")
        waitForClickable("orderdate")
        click("orderdate")
        Thread.sleep(5000)
        waitFor("ordernumber")

        String ordernumber = readText("ordernumber")
        String materialnumber = readText("materialno")
        String ordervalue= readText("ordervalue")
        String ordertype= readText("ordertype")
        String purchaseorder= readText("purchaseorder")
        println(ordernumber)
        return  Arrays.asList(ordernumber, materialnumber, ordervalue, ordertype, purchaseorder)


    }

    def orderHistoryVerificationPROD(String Ponumber)
    {


        browser.driver.navigate().refresh()
        waitForClickable("custompo")
        typeText("custompo", Ponumber)
        println("PO Number entered for order"+Ponumber)



    }

    def reorder()
    {

        waitForClickable("reorder")
        Thread.sleep(10000)
        click("reorder")
        waitForClickable("submitorder")
        click("submitorder")
        Thread.sleep(5000)
        //waitFor("POerror")
        scrolltop()
        waitForClickable("customporeference")
        typeText("customporeference", dateTimeStamp())
        typeText("specialinstructions", "special instructions")
        typeText("referencenote", "reference note")
        waitForClickable("saveorder")
        click("saveorder")
        Thread.sleep(15000)

        return readCurrenturl()

    }

    def returnAnItem()
    {
        Thread.sleep(25000)

        waitForClickable("returns")
        click("returns")
        waitForClickable("searchreturns")
        jsclick("searchreturns")
        waitForClickable("invoicenumber")x
        typeText("invoicenumber", "1080001537")
        waitForClickable("submitreturn")
        Thread.sleep(20000)
        click("submitreturn")
        waitForClickable("firstresult")
        click("firstresult")
        waitForClickable("returnnext")
        Thread.sleep(2000)
        jsclick("returnnext")
        waitForClickable("quantity")
        typeText("quantity", "2")
        Thread.sleep(10000)
        waitForClickable("reason")
        click("reason")
        click("reasonselect")
        waitForClickable("returnnext2")
        click("returnnext2")
        waitForClickable("submitreturn2")
        Thread.sleep(10000)
        click("submitreturn2")
        waitForClickable("viewreturnsummary")
        click("viewreturnsummary")
    }

    def returnAnItemwithoutSearch(String countrycode)
    {
        Thread.sleep(25000)

        waitForClickable("returns")
        click("returns")

        waitForClickable("firstresult")
        click("firstresult")
        Thread.sleep(7000)
        waitForClickable("returnnext")
        jsclick("returnnext")
        waitForClickable("quantity")
        typeText("quantity", "2")
        Thread.sleep(10000)
        waitForClickable("reason")
        click("reason")
        waitForClickable("reasonselect")
        click("reasonselect")
       /* if(countrycode.equalsIgnoreCase("MY"))
        {
            waitForClickable("priceoverride")
            typeText("priceoverride", "2")
        } */
        waitForClickable("returnreference")
        typeText("returnreference", "1234567890")
        waitForClickable("returnspecial")
        typeText("returnspecial", "special instructions")
        waitForClickable("returnnext2")
        click("returnnext2")
        waitForClickable("submitreturn2")
        Thread.sleep(5000)
        click("submitreturn2")
        navigateToUrl("https://uat.ezrx.com/return-summary")
        Thread.sleep(10000)
        waitForClickable("returnselection")
        click("returnselection")
        waitForClickable("active")
        click("active")
        waitForClickable("ezreturnid")
        String returnid = readText("ezreturnid")
        return returnid
    }

    def submitOrder()
    {
        Thread.sleep(10000)
        waitForClickable("submitorder")
        jsclick("submitorder")
        waitForClickable("orderhistory")
        click("orderhistory")
    }

    def addBonusItem()
    {
        waitForClickable("addbonus")

      //  scroll("addbonus")
       // JavascriptExecutor js = (JavascriptExecutor) browser.driver;
        //js.executeScript("window.scrollBy(0,800)")
        Thread.sleep(10000)

        jsclick("addbonus")
        waitFor("searchmaterial")
        waitForClickable("searchmaterial")
        typeText("searchmaterial", "cream")
        waitFor("selectfirstitem")
        waitForClickable("selectfirstitem")
        Thread.sleep(10000)
        jsclick("selectfirstitem")
        waitForClickable("plusitem")
        jsclick("plusitem")
       // waitForClickable("additem")
        jsclick("additem")
        waitFor("text")
    }

    def approveReturn(String returnid)
    {
        waitForClickable("approverpayment")
        click("approverpayment")
        Thread.sleep(10000)
        waitForClickable("searchpayment")
        click("searchpayment")
        waitForClickable("returnid")
        typeText("returnid", returnid)
        waitForClickable("submitpayment")
        click("submitpayment")
        waitForClickable("returnididsplay")
        waitForClickable("review")
        click("review")
        waitForClickable("rejectbtn")
        waitForClickable("activitylog")
        waitForClickable("approvebtn")
        click("approvebtn")
        waitForClickable("reasonapproval")
        typeText("reasonapproval", "reson for approval")
        waitForClickable("confirmbtn")
        click("confirmbtn")
        waitFor("statusapproved")
        Thread.sleep(20000)
        browser.driver.navigate().refresh()
        waitForClickable("ROnumber")
        String ronumber = readText("ROnumber")
        return ronumber
    }

    def addtoFavorites() {

        submiteZRxSurvery()
        scroll("clearcart")
        waitFor("materialnumber2")
        String material1 = readText("materialnumber1")
        String material2 = readText("materialnumber2")
        String material3 = readText("materialnumber3")
      //  scroll
        waitForClickable("favourite")
        Thread.sleep(2000)
        jsclick("favourite")
        waitForClickable("favourite2")
        Thread.sleep(2000)
        jsclick("favourite2")

       waitFor("saved")
        return Arrays.asList(material1, material2)


    }

    def addtfromFavorites()
    {
        waitForClickable("addfromfavourite")
        Thread.sleep(5000)
        click("addfromfavourite")
        waitForClickable("materialfavorite1")
        String materail1 = readText("materialfavorite1")
        String materail2 = readText("materialfavorite2")
        //String materail3 = readText("materialfavorite3")

        waitForClickable("favoriteaddtocart")
        click("favoriteaddtocart")

        waitForClickable("deletebutton")
        click("deletebutton")
        waitForClickable("deletebutton2")
        Thread.sleep(5000)
        click("deletebutton2")
      //  waitForClickable("deletebutton3")
       // click("deletebutton3")
        clickAnyWhere(browser.driver)
        return Arrays.asList(materail1, materail2)
    }

    def clearCart()
    {
        scroll("specialinstructions")
        waitForClickable("clearcart")
        Thread.sleep(5000)
        jsclick("clearcart")
    }

    def goToOrderSummary()
    {
        scrolltop()
        waitForClickable("cart")
        click("cart")
        waitForClickable("plus_sign")
        Thread.sleep(5000)
        click("plus_sign")
        waitFor("deleteitems")
        waitFor("grandtotal")
        String grandtotal = readText("grandtotal")
        waitForClickable("gotoorder")
        click("gotoorder")
        waitFor("totalinsubmitorder")
        String totalinorder = readText("totalinsubmitorder")
        checkifVisible("subtotal")
        checkifVisible("vatpercentage")
        checkifVisible("vatamount")
        Assert.assertEquals(grandtotal, totalinorder)
    }

    def goToOrderSummaryProd()
    {
        scrolltop()
        waitForClickable("cart")
        click("cart")
        waitForClickable("plus_sign")
        Thread.sleep(5000)
        click("plus_sign")
        waitFor("deleteitems")
        waitFor("grandtotal")
        String grandtotal = readText("grandtotal")
        waitForClickable("gotoorder")
        click("gotoorder")
        waitFor("totalinsubmitorder")
        String totalinorder = readText("totalinsubmitorder")
        checkifVisible("subtotal")

        Assert.assertEquals(grandtotal, totalinorder)
    }

    def ezrxLogout()
    {
        waitForClickable("userprofile")
        mouseOver("userprofile", browser.driver)
        waitForClickable("ezrxlogout")
        click("ezrxlogout")
        waitForClickable("loginwithSSO")
    }

    def viewCustomerCode()
    {
        waitForClickable("userprofile")
        mouseOver("userprofile", browser.driver)
        waitForClickable("admin")
        click("admin")
        waitForClickable("customercodeconfig")
        click("customercodeconfig")
        waitFor("editconfig")
        Thread.sleep(10000)
        jsclick("editconfig")
        waitFor("customercodesalesorg")
        checkifVisible("customercodesalesorg")
        checkifVisible("customercodecc")
        checkifVisible("poswitch")
        checkifVisible("analyticsswitch")
        checkifVisible("diablesreturns")
        checkifVisible("enable2fa")
        checkifVisible("priceoverridecc")
        checkifVisible("diablesoa")
        checkifVisible("back")
        checkifVisible("update")

    }

    def manageUser(String username)
    {
        waitForClickable("userprofile")
        mouseOver("userprofile", browser.driver)
        waitForClickable("manageusers")
        click("manageusers")
        waitForClickable("searchuser")
        typeText("searchuser", username)
        Thread.sleep(15000)
        int size = checkListSize("resultsize")
        Assert.assertEquals(size, 1)
        String resultfound = readText("resultusername")
        Assert.assertEquals(username, resultfound)
        waitForClickable("disable")
        click("disable")
        waitForClickable("disableok")
        click("disableok")
        waitForClickable("enable")
        Thread.sleep(5000)
        click("enable")
//        waitForClickable("disableok")
  //      click("disableok")
        waitForClickable("edituser")
        click("edituser")
        waitForClickable("updateuser")
        click("updateuser")

    }

    def uploadIncorrectInvoice()
    {
       // browser.driver.navigate().refresh()
        waitFor("pocontainer")
        // click("pocontainer")

        String filePath=System.getProperty("user.dir")+"\\src\\test\\resources\\SearchUrlConfig.groovy";
        uploadFileUisngRobot("pocontainer", filePath)
       // waitFor("uploadinvoice")
       // uploadFile("uploadinvoice",)
        waitFor("cttext")
    }

    def uploadInvoice()
    {

       // browser.driver.navigate().refresh()
        waitFor("pocontainer")
      // click("pocontainer")

        String filePath=System.getProperty("user.dir")+"\\src\\test\\resources\\testimage.png";
        uploadFileUisngRobot("pocontainer", filePath)
        waitFor("sucessmessage")
    }

    def deleteInvoice() {
        waitForClickable("deleteinvoice")
        click("deleteinvoice")

    }

    def uploadxlsInvoice()
    {
       // browser.driver.navigate().refresh()
        waitFor("pocontainer")
        // click("pocontainer")

        String filePath=System.getProperty("user.dir")+"\\src\\test\\resources\\LT_Quick_Order_Upload_Template.xls";
        uploadFileUisngRobot("pocontainer", filePath)
        waitFor("sucessmessage")
    }

    def uploadcsvInvoice()
    {
      //  browser.driver.navigate().refresh()
        waitFor("pocontainer")
        // click("pocontainer")

        String filePath=System.getProperty("user.dir")+"\\src\\test\\resources\\CSVSample_user.csv";
        uploadFileUisngRobot("pocontainer", filePath)
        waitFor("sucessmessage")
    }


    def addAdditonalInformationNegative()
    {
        scrolltop()
        waitForClickable("customporeference")
        String datetimestamp = dateTimeStamp()
        typeText("customporeference", datetimestamp)
        typeText("specialinstructions", "special instructions")
        typeText("referencenote", "reference note")
        waitForClickable("deliverydate")
        scroll("specialinstructions")
        Thread.sleep(12000)

        submiteZRxSurvery()
        println("reached ezrx survey")
        Thread.sleep(5000)
        waitForClickable("paymentterm")
        click("paymentterm")
        waitForClickable("selectpaymentterm")
        click("selectpaymentterm")
        typeText("contactperson", "cintact person")
        typeText("contactnumber", "1234567890")
        return  datetimestamp


    }

    def submitOrderFailure()
    {
        Thread.sleep(10000)
        waitForClickable("submitorder")
        jsclick("submitorder")
        Thread.sleep(5000)
    }

    def submiteZRxSurvery()
    {
        Thread.sleep(10000)
        int countIframesInPage = browser.driver.findElements(By.name("survey-iframe-SI_6LmI5OjlvYr4e2y")).size()

        if(countIframesInPage!=0) {
            Thread.sleep(10000)
            browser.driver.switchTo().frame("survey-iframe-SI_6LmI5OjlvYr4e2y")
            waitForClickable("rating8")
            click("rating8")
            waitForClickable("nextbuttonsurvey")
            click("nextbuttonsurvey")
            waitForClickable("comments")
            typeText("comments", "test coments")
            waitForClickable("nextbuttonsurvey")
            click("nextbuttonsurvey")
            waitForClickable("placeanorder")
            click("placeanorder")
            waitForClickable("nextbuttonsurvey")
            click("nextbuttonsurvey")
            waitFor("endofsurvey")
            browser.driver.switchTo().defaultContent()
            waitForClickable("closesurvey")
            click("closesurvey")
        }
    }

    def seachwithmaterialnumber(String materialno) {

        waitFor("orderwindows")
        waitForClickable("materialid")
        typeText("materialid", materialno)
        clickAnyWhere(browser.driver)
        waitForClickable("materialresults")
        Thread.sleep(10000)
        String materialresutls = readText("materialresults")

        clear("materialid")
        return materialresutls
    }

    def seachwithOrderID(String orderId) {

        waitFor("filtertext")
        waitForClickable("orderid")
        typeText("orderid", orderId)
        Thread.sleep(10000)
        clickAnyWhere(browser.driver)
        waitForClickable("orderidresults")
        String orderidresults = readText("orderidresults")

        clear("orderid")
        return orderidresults
    }

    def exportResults() {

        waitForClickable("export")
        click("export")
        Thread.sleep(5000)
    }


    def changeOrderStatusandVerify() {
        scrolltop()
        waitForClickable("orderstaus")
        click("orderstaus")
        waitForClickable("ordercreated")
        click("ordercreated")
        waitForClickable("pendingorder")
        click("pendingorder")
        waitForClickable("failedorder")
        click("failedorder")
        waitForClickable("cancelled")
        click("cancelled")
        waitForClickable("outfordelivery")
        click("outfordelivery")
        waitForClickable("pockinprogress")
        click("pockinprogress")
        waitForClickable("clearstatus")
        click("clearstatus")
        Thread.sleep(10000)

    }

    def verifyfooterlinks()
    {

        Thread.sleep(10000)
        scroll("footer")
        waitForClickable("vieworders")
        click("vieworders")
        Thread.sleep(10000)
        String vieworder = readCurrenturl()
        navigateback()
        waitForClickable("createorders")
        click("createorders")
        Thread.sleep(10000)
        String createorder = readCurrenturl()

        waitForClickable("termsandconditions")
        click("termsandconditions")
        Thread.sleep(10000)
        String termsandconditions = readCurrenturl()
        navigateback()
        navigateback()
        waitForClickable("footer")
        scroll("footer")

        waitForClickable("privacy")
        click("privacy")
        Thread.sleep(10000)
        String privacy = readCurrenturl()

        waitForClickable("createanaccount")
        click("createanaccount")
        Thread.sleep(10000)

        switchtonextTab(browser.driver)
        String createanaccount = readCurrenturl()

        return Arrays.asList(vieworder, createorder, termsandconditions, privacy, createanaccount)

    }

    def UpdateSalesorgSettings()
    {
        waitForClickable("userprofile")
        mouseOver("userprofile", browser.driver)
        waitForClickable("admin")
        click("admin")
        waitForClickable("salesorderconfig")
        click("salesorderconfig")
        waitForClickable("MDIph")
        click("MDIph")

        waitForClickable("poreferencerequired")
        click("poreferencerequired")
        waitForClickable("enablebatchnumber")
        click("enablebatchnumber")
        waitForClickable("enablepaymentterms")
        click("enablepaymentterms")
        waitForClickable("enablecontactperson")
        click("enablecontactperson")
        waitForClickable("updatesalesconfig")
        click("updatesalesconfig")

    }

    def PostSettingsOrder()
    {
        waitForClickable("createorder")
        click("createorder")
        Thread.sleep(10000)
      //  checkNotVisible("customporeference")
        checkNotVisible("paymentterm")
        checkNotVisible("contactperson")
}

    def additemstocartProd()
    {

            waitForClickable("plusquanity1")
            for(int i = 0; i <3;i++)
            {
                Thread.sleep(1000)
                click("plusquanity1")
                Thread.sleep(1000)
            }
            waitForClickable("plusquanity2")
            click("plusquanity2")
//        click("plusquanity3")

            waitForClickable("addtocart1")
            click("addtocart1")
            Thread.sleep(1000)
            waitForClickable("addtocart2")
            click("addtocart2")
            Thread.sleep(1000)
            waitForClickable("addtocart3")
            Thread.sleep(3000)

        }

    def additemstocartProdTW() {

      //  scroll("plusquanity1")

        Thread.sleep(2000)
        waitForClickable("plusquanity1")
        for(int i = 0; i <3;i++)
        {
            Thread.sleep(1000)
            click("plusquanity1")
            Thread.sleep(1000)
        }
        waitForClickable("plusquanity2")
        click("plusquanity2")
//        click("plusquanity3")

        waitForClickable("addtocart1")
        click("addtocart1")
        Thread.sleep(1000)
        waitForClickable("addtocart2")
        click("addtocart2")
        Thread.sleep(1000)
        waitForClickable("addtocart3")
        Thread.sleep(3000)

    }

    def searchByPrincipal(String principal)
    {
        waitForClickable("searchbypricipal")
        typeText("searchbypricipal", principal)
        waitForTimePeriod(5000)

    }

    def searchwithPricipalinOH(String s) {

        waitForClickable("OHprincipal")
        typeText("OHprincipal", s)
        waitForTimePeriod(10000)
        waitForClickable("orderidresults")
        String orderidresults = readText("orderidresults")
        println("Order details found are"+orderidresults)
        return orderidresults
    }
}

