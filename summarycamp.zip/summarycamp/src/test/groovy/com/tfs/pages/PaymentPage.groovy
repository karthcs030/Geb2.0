package com.tfs.pages

import com.tfs.common.webDriverLibrary
import geb.Browser
import io.qameta.allure.Step
import org.openqa.selenium.By

//import BaseGebSpec
//import geb.Page

class PaymentPage extends webDriverLibrary{

    static Browser browser

    PaymentPage(Browser browser){
        this.browser=browser
    }

    @Step("Navigate to payment information page")
    def navigateToPayment()
    {
        waitFor("account")
        click("account")
        waitForClickable("paymentinformation")
        click("paymentinformation")
    }

    @Step("Choose appointment for payment")
    def chooseAppointmentforPayment()
    {
        waitForClickable("clockicon")
        click("clockicon")
        waitForClickable("paynow")
        click("paynow")
        screenshot(browser.driver)


    }
    @Step("Pay through credit card")
    def payThoughCredicard()
    {
        waitForClickable("creditcard")
        click("creditcard")
        waitForClickable("cardnumber")
        typeText("cardnumber", "4123450131001381")
        waitForClickable("expiry")
        typeText("expiry", "1225")
        waitForClickable("cvv")
        typeText("cvv", "123")
        Thread.sleep(5000)
        waitForClickable("completeorder")
        click("completeorder")
        waitFor("passkey")
        typeText("passkey", "mctest1")
        waitForClickable("submit")
        click("submit")
        screenshot(browser.driver)

        waitFor("paymentsucess")
        Thread.sleep(15000)
        return readCurrenturl();
    }

}

