package com.tfs.pages

import com.tfs.common.configdataFetcher
import com.tfs.common.webDriverLibrary
import geb.Browser
import io.qameta.allure.Step
import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class RNADesigner extends webDriverLibrary {

    static Browser browser

    RNADesigner(Browser browser) {
        this.browser = browser
    }

    Logger log = LoggerFactory.getLogger(RNADesigner.class)

    @Step("Add rnaDesigner to cart")
    def addfromRNADesigner(WebDriver driver)
    {
        String url = driver.getCurrentUrl()

        if (url.contains("qa")) {
            driver.navigate().to("https://rnaidesigner.ezconsult.com/rnaiexpress/rnaiExpress.jsp?SID=srch-hj-10620310")
        } else {
            driver.navigate().to("https://rnaidesigner.ezconsult.com/rnaiexpress/rnaiExpress.jsp?SID=srch-hj-10620310")
        }

        Thread.sleep(5000)


        waitForElementToLoad(By.xpath(configdataFetcher.configData("browserbygene")))
        WebElement browserbygene = driver.findElement(By.xpath(configdataFetcher.configData("browserbygene")))
        jsclick(browserbygene, driver)


        waitForElementToLoad(By.xpath(configdataFetcher.configData("gprotein")))
        WebElement gprotein = driver.findElement(By.xpath(configdataFetcher.configData("gprotein")))
        jsclick(gprotein, driver)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("tube")))
        WebElement tube = driver.findElement(By.xpath(configdataFetcher.configData("tube")))
        jsclick(tube, driver)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("closeRNA")))
        WebElement closeRNA = driver.findElement(By.xpath(configdataFetcher.configData("closeRNA")))
        jsclick(closeRNA, driver)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("StealthRna")))
        WebElement StealthRna = driver.findElement(By.xpath(configdataFetcher.configData("StealthRna")))
        jsclick(StealthRna, driver)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("addtocartrnadesigner")))
        WebElement addtocartrnadesigner = driver.findElement(By.xpath(configdataFetcher.configData("addtocartrnadesigner")))
        jsclick(addtocartrnadesigner, driver)


        waitForElementToLoad(By.xpath(configdataFetcher.configData("testresearchername")))
        driver.findElement(By.xpath(configdataFetcher.configData("testresearchername"))).sendKeys("targetname")

        waitForElementToLoad(By.xpath(configdataFetcher.configData("order")))
        WebElement order = driver.findElement(By.xpath(configdataFetcher.configData("order")))
        jsclick(order, driver)
        Thread.sleep(5000)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("proceed")))


    }

    @Step("Add rnaDesigner to cart for china")
    def addfromRNADesignerCN(WebDriver driver)
    {
        String url = driver.getCurrentUrl()

        if (url.contains("qa")) {
            driver.navigate().to("https://rnaidesigner.ezconsult.com/rnaiexpress/rnaiExpress.jsp?SID=srch-hj-10620310")
        } else {
            driver.navigate().to("https://rnaidesigner.ezconsult.com/rnaiexpress/rnaiExpress.jsp?SID=srch-hj-10620310")
        }

        Thread.sleep(5000)


        waitForElementToLoad(By.xpath(configdataFetcher.configData("browserbygene")))
        WebElement browserbygene = driver.findElement(By.xpath(configdataFetcher.configData("browserbygene")))
        jsclick(browserbygene, driver)


        waitForElementToLoad(By.xpath(configdataFetcher.configData("gprotein")))
        WebElement gprotein = driver.findElement(By.xpath(configdataFetcher.configData("gprotein")))
        jsclick(gprotein, driver)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("tube")))
        WebElement tube = driver.findElement(By.xpath(configdataFetcher.configData("tube")))
        jsclick(tube, driver)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("closeRNA")))
        WebElement closeRNA = driver.findElement(By.xpath(configdataFetcher.configData("closeRNA")))
        jsclick(closeRNA, driver)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("StealthRna")))
        WebElement StealthRna = driver.findElement(By.xpath(configdataFetcher.configData("StealthRna")))
        jsclick(StealthRna, driver)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("addtocartrnadesigner")))
        WebElement addtocartrnadesigner = driver.findElement(By.xpath(configdataFetcher.configData("addtocartrnadesigner")))
        jsclick(addtocartrnadesigner, driver)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("RNAcustomername")))
        driver.findElement(By.xpath(configdataFetcher.configData("RNAcustomername"))).sendKeys("targetname")

        waitForElementToLoad(By.xpath(configdataFetcher.configData("RNaphone")))
        driver.findElement(By.xpath(configdataFetcher.configData("RNaphone"))).sendKeys("1234567890")

        waitForElementToLoad(By.xpath(configdataFetcher.configData("RNAfax")))
        driver.findElement(By.xpath(configdataFetcher.configData("RNAfax"))).sendKeys("1234567890")

        waitForElementToLoad(By.xpath(configdataFetcher.configData("RNAemail")))
        driver.findElement(By.xpath(configdataFetcher.configData("RNAemail"))).sendKeys("karthik.ml@ezconsult.com")
        waitForElementToLoad(By.xpath(configdataFetcher.configData("testresearchername")))
        driver.findElement(By.xpath(configdataFetcher.configData("testresearchername"))).sendKeys("targetname")

        waitForElementToLoad(By.xpath(configdataFetcher.configData("order")))
        WebElement order = driver.findElement(By.xpath(configdataFetcher.configData("order")))
        jsclick(order, driver)
        Thread.sleep(5000)

        waitForElementToLoad(By.xpath(configdataFetcher.configData("finalconfirmationmessage")))


    }







}
