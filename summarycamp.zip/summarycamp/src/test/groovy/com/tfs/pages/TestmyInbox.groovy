package com.tfs.pages


import com.sun.mail.imap.protocol.Item
import microsoft.exchange.webservices.data.core.ExchangeService
import microsoft.exchange.webservices.data.core.PropertySet
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName
import microsoft.exchange.webservices.data.core.enumeration.search.LogicalOperator
import microsoft.exchange.webservices.data.core.service.folder.Folder
import microsoft.exchange.webservices.data.core.service.item.EmailMessage
import microsoft.exchange.webservices.data.core.service.schema.ItemSchema
import microsoft.exchange.webservices.data.credential.ExchangeCredentials
import microsoft.exchange.webservices.data.credential.WebCredentials
import microsoft.exchange.webservices.data.property.complex.FileAttachment
import microsoft.exchange.webservices.data.search.FindItemsResults
import microsoft.exchange.webservices.data.search.ItemView
import microsoft.exchange.webservices.data.search.filter.SearchFilter
import org.apache.commons.collections.CollectionUtils


public class TestmyInbox {


    private static ExchangeService createConnection() throws Exception {
        String email = "ITQASupport@ezconsult.com";
        String password = "ITqa851!";
        ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
        ExchangeCredentials credentials = new WebCredentials(email, password, "apac.thermo.com");
        service.setUrl(new URI("https://outlook.office365.com/EWS/Exchange.asmx"));
        service.setCredentials(credentials);
        println("Connection sucessfully created")
        return service;
    }

    void read(ExchangeService service){
        Folder folder = Folder.bind(service, WellKnownFolderName.Inbox)
        FindItemsResults<Item> results = service.findItems(folder.getId(), new ItemView(10))
        for (Item item : results) {
            EmailMessage emailMessage = EmailMessage.bind(service, item.getId())
            println("Sender: ${emailMessage.getSender()}")
            println("Subject: ${emailMessage.getSubject()}")
        }
    }

    private static void readAttachmentEmail(ExchangeService service) throws Exception {
        // Bind to the Inbox.
        Folder inbox = Folder.bind(service, WellKnownFolderName.Inbox);
        // set number of items you want to retrieve
        ItemView view = new ItemView(5);


        List<SearchFilter> searchFilterCollection = new ArrayList<>();
        // flag to pick only email which contains attachments
        searchFilterCollection.add(new SearchFilter.IsEqualTo(ItemSchema.HasAttachments, Boolean.FALSE));
        searchFilterCollection.add(new SearchFilter.ContainsSubstring(ItemSchema.Subject, "70820807"));
        SearchFilter finalSearchFilter = new SearchFilter.SearchFilterCollection(LogicalOperator.And, searchFilterCollection);
        ArrayList<Item> items = service.findItems(inbox.getId(), finalSearchFilter, view).getItems();



       if (!CollectionUtils.isEmpty(items)) {
            Item item = items.get(0);
            System.out.println("id==========" + item.getDateTimeReceived());
            System.out.println("sub==========" + item.getSubject());
            EmailMessage message = EmailMessage.bind(service, item.getId(), new PropertySet(ItemSchema.Attachments));
            FileAttachment attachment = (FileAttachment) message.getAttachments().getItems().get(0);
            attachment.load(" < attachment save directory > " + attachment.getName());
       }

    }
}
