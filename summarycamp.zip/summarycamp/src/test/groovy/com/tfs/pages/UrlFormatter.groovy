package com.tfs.pages

import geb.Page
import org.openqa.selenium.By
import org.openqa.selenium.WebElement
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class UrlFormatter extends Page{
    Logger log = LoggerFactory.getLogger(UrlFormatter.class)
    static ConfigObject config

    def withKeyword(String keyword) {
        config.searchResultUrl + keyword
    }

    def selectFA(String FA) {
        WebElement dropdownEl = driver.findElement(By.xpath("/*//*[@id='focusAreaSelector']"))
        dropdownEl.click();
        WebElement optionEl = driver.findElement(By.xpath("/*//*[@id='chosenselector_chosen']//li[text()='" + FA + "']"));
        optionEl.click();
        Thread.sleep(3000L)
    }

    def withonlineOffers() {
        config.onlineOffersUrl
    }

    def withSEKeyword(String keyword) {
        config.seSrpUrl+keyword;
    }

    def withPersona(String keyword, String persona) {
        config.searchResultUrl+keyword+"&persona="+persona
    }

    def withCustomGroup(String customGroup) {
        config.customGroupUrl+customGroup;
    }
}

