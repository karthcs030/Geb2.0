package com.tfs.pages


import com.tfs.common.webDriverLibrary
import geb.Browser
import io.qameta.allure.Step
import org.openqa.selenium.JavascriptExecutor

//import BaseGebSpec

//import geb.Page

class VaccinationPage extends webDriverLibrary {
    static Browser browser

    VaccinationPage(Browser browser){
        this.browser=browser
    }

    @Step("Book a Self consulation")
    def registerForVaccine() {

        waitForClickable("registercovid")
        click("registercovid")
        waitForClickable("nextcovid")
        click("nextcovid")
        /*waitForClickable("addlgu")
        click("addlgu")
        waitForClickable("laspinas")
        click("laspinas")
        waitForClickable("nextcovid")
        click("nextcovid")*/
        waitForClickable("priority")
        click("priority")
        waitForClickable("ROAP")
        click("ROAP")
        waitForClickable("nextcovid")
        click("nextcovid")
        waitForClickable("workidnumber")
        click("workidnumber")
        waitForClickable("priroitygroupnumber")
        typeText("priroitygroupnumber", "123456789")
       // scroll("region")
        waitForClickable("region")
        click("region")
        waitFor("regionselect")
        jsclick("regionselect")
        JavascriptExecutor js = (JavascriptExecutor) browser.driver;
        js.executeScript("window.scrollBy(0,200)")
        Thread.sleep(5000)

        waitForClickable("province")
        click("province")
        waitFor("provinceselect")
        jsclick("provinceselect")
        Thread.sleep(10000)

        waitForClickable("city")
        click("city")
        waitForClickable("cityselect")
        jsclick("cityselect")
        js.executeScript("window.scrollBy(0,400)")
        Thread.sleep(10000)

        waitForClickable("profession")
        click("profession")
        click("profession")
        waitForClickable("professionselect")
        jsclick("professionselect")
        Thread.sleep(5000)
        waitForClickable("electronicconsent")
        click("electronicconsent")

        waitForClickable("nextcovid")
        click("nextcovid")

        waitForClickable("confirmcovid")
        click("confirmcovid")

        waitForClickable("okcovid")
        Thread.sleep(3000)
        click("okcovid")

        waitForClickable("VIMSIR")
        click("VIMSIR")




    }



}

