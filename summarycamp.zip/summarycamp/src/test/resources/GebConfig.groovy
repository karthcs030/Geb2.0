//import com.aoe.gebspockreports.GebReportingListener
import io.github.bonigarcia.wdm.ChromeDriverManager
import io.github.bonigarcia.wdm.FirefoxDriverManager
import io.github.bonigarcia.wdm.InternetExplorerDriverManager

import org.openqa.selenium.chrome.ChromeDriver
import org.openqa.selenium.chrome.ChromeOptions
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.ie.InternetExplorerDriver

import org.openqa.selenium.remote.DesiredCapabilities
// Location where Geb saves the screenshots and HTML dumps at the end of each test
//reportsDir = 'build/test-reports' - @see : geb.build.reportsDir in build.gradle

//reportingListener = new GebReportingListener()
//reportsDir = 'build/geb-spock-reports'

atCheckWaiting = true
autoClearCookies = false
reportOnTestFailureOnly=true

environments {

    // run with "gradlew -Dgeb.env=chrome test", see build.gradle for default driver

    chrome {
        // Download and configure ChromeDriver using https://github.com/bonigarcia/webdrivermanager
       // ChromeDriverManager.chromedriver().version("72.0.3626.7").setup()
        ChromeDriverManager.chromedriver().setup()

        driver = {
            ChromeOptions options = new ChromeOptions()
            options.addArguments("--start-maximized");
            options.addArguments("--disable-gpu");

            new ChromeDriver(options) }

    }



    // See: http://code.google.com/p/selenium/wiki/ChromeDriver
    chromeHeadless {
        driver = {
            ChromeOptions options = new ChromeOptions()
            options.addArguments("--headless");
            options.addArguments("--disable-gpu");
            options.addArguments("--start-maximized");
            options.addArguments("disable-infobars");
         //   options.setAcceptInsecureCerts(true);
           // options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
            new ChromeDriver(options)
        }
    }

    firefox {
        // Download and configure Marionette using https://github.com/bonigarcia/webdrivermanager
        FirefoxDriverManager.firefoxdriver().setup()
        driver = { new FirefoxDriver() }
    }

    ie {
        // Download and configure Marionette using https://github.com/bonigarcia/webdrivermanager
        InternetExplorerDriverManager.iedriver().setup()


        //System.setProperty("webdriver.ie.driver", "C:\\Users\\karthik.ml\\.m2\\repository\\webdriver\\IEDriverServer\\x64\\3.150\\IEDriverServer.exe");
        DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
        capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
        //...
        capabilities.setCapability("RequireWindowFocus", true);
        capabilities.setCapability("IgnoreZoomLevel",true)
        capabilities.setCapability("EnablePersistentHover", true)
        capabilities.setCapability("EnableNativeEvents", true)
        capabilities.setCapability("IntroduceInstabilityByIgnoringProtectedModeSetting", true)
        //WebDriver driver = new InternetExplorerDriver(capabilities);
        driver = { new InternetExplorerDriver(capabilities)}




    }

   /*edge {
        // Download and configure Marionette using https://github.com/bonigarcia/webdrivermanager
        EdgeDriverManager.edgedriver().setup()
        driver = { new EdgeDriver() }*/

    /*safari {
        // Download and configure Marionette using https://github.com/bonigarcia/webdrivermanager
        SafariDriverService.createDefaultService()
        driver = { new SafariDriver() }
    }*/


}


/*public void run(IHookCallBack iHookCallBack, ITestResult iTestResult) {
    iHookCallBack.runTestMethod(iTestResult);
    if (iTestResult.getThrowable() != null) {
        this.saveScreenshot(iTestResult.getName(), driver);
    }
}*/