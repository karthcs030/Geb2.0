/*
 * Copyright (c) 2018. https://automationschool.com
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

environments {
    test {
        home = "http://www.dev2.ezconsult.com/"
        seSrpUrl = "https://www.dev2.ezconsult.com/search/se/results?keyword="
        searchResultUrl="https://www.dev2.ezconsult.com/search/results?query="
        onlineOffersUrl="https://www.dev2.ezconsult.com/search/onlineoffers"
        tfBrowsePage="https://www.dev2.ezconsult.com/search/browse/category"
        seBrowsePage="https://www.dev2.ezconsult.com/search/se/contract-lab"
        customGroupUrl="https://www.dev2.ezconsult.com/search/browse/results?customGroup="
    }
    dev {
        home = "http://www.dev.ezconsult.com/"
        ezrxhome="https://dev.ezrx.com/"
        ezrxmphome="https://mp-dev.ezrx.com/"
        ezrxmseller="https://seller-center-mpmy-dev.ezrx.com/"
        ezrxsellerreg="https://supplier-registration-mpmy-dev.ezrx.com/"
        seSrpUrl = "https://www.dev.ezconsult.com/search/se/results?keyword="
        searchResultUrl="https://www.dev.ezconsult.com/search/results?query="
        onlineOffersUrl="https://www.dev.ezconsult.com/search/onlineoffers"
        tfBrowsePage="https://www.dev.ezconsult.com/search/browse/category"
        seBrowsePage="https://www.dev.ezconsult.com/search/se/contract-lab"
        customGroupUrl="https://www.dev.ezconsult.com/search/browse/results?customGroup="
        ampliseq="https://dev.ampliseq.com/"
    }
    dev1 {
        home = "http://www.dev.ezconsult.com/"
        ezrxhome="https://uat.ezrx.com/"

        seSrpUrl = "https://www.dev.ezconsult.com/search/se/results?keyword="
        searchResultUrl="https://www.dev.ezconsult.com/search/results?query="
        onlineOffersUrl="https://www.dev.ezconsult.com/search/onlineoffers"
        tfBrowsePage="https://www.dev.ezconsult.com/search/browse/category"
        seBrowsePage="https://www.dev.ezconsult.com/search/se/contract-lab"
        customGroupUrl="https://www.dev.ezconsult.com/search/browse/results?customGroup="
        ampliseq="https://dev.ampliseq.com/"
    }
    stage {
        home = "https://ezconsult-webapp-staging.azurewebsites.net/signin"
        ezrxhome="https://zpprodapiportalapimgmt.apimanagement.ap1.hana.ondemand.com/signin"
        seSrpUrl = "http://www.ezconsult.com/search/se/results?keyword="
        searchResultUrl="http://www.ezconsult.com/search/results?query="
        onlineOffersUrl="http://www.ezconsult.com/search/onlineoffers"
        tfBrowsePage="http://www.ezconsult.com/search/browse/category"
        seBrowsePage="http://www.ezconsult.com/search/se/contract-lab"
        customGroupUrl="http://www.ezconsult.com/search/browse/results?customGroup="
        ampliseq="https://ampliseq.com/"
        cnhome = "http://www.ezconsult.cn"
        qa5home = "http://www.qa5.ezconsult.com/"
        availaabilityV1="http://10.3.7.142:8091/query"
        availaabilityR1="https://tfcommerce-api-eks.cloudqa.ezconsult.net/api/store/sku/availability/"
        addtoCart="https://tfcommerce-api-eks.cloudqa.ezconsult.net/api/store/carts/directAddToCart"
        checkoutIntiate="https://tfcommerce-api-eks.cloudqa.ezconsult.net/api/store/core/checkout/initiate"


    }
    qa2 {
        home = "http://www.qa2.ezconsult.com/"
        ezrxhome="https://zpprodapiportalapimgmt.apimanagement.ap1.hana.ondemand.com/signin"
        seSrpUrl = "https://www.qa2.ezconsult.com/search/se/results?keyword="
        searchResultUrl="https://www.qa2.ezconsult.com/search/results?query="
        onlineOffersUrl="https://www.qa2.ezconsult.com/search/onlineoffers"
        tfBrowsePage="https://www.qa2.ezconsult.com/search/browse/category"
        seBrowsePage="https://www.qa2.ezconsult.com/search/se/contract-lab"
        customGroupUrl="https://www.qa2.ezconsult.com/search/browse/results?customGroup="
    }
    qa3 {
        home = "http://www.qa3.ezconsult.com/"
        seSrpUrl = "https://www.qa3.ezconsult.com/search/se/results?keyword="
        searchResultUrl="https://www.qa3.ezconsult.com/search/results?query="
        onlineOffersUrl="https://www.qa3.ezconsult.com/search/onlineoffers"
        tfBrowsePage="https://www.qa3.ezconsult.com/search/browse/category"
        seBrowsePage="https://www.qa3.ezconsult.com/search/se/contract-lab"
        customGroupUrl="https://www.qa3.ezconsult.com/search/browse/results?customGroup="
    }
    qa4 {
        home = "http://www.qa4.ezconsult.com/"
        seSrpUrl = "https://www.qa4.ezconsult.com/search/se/results?keyword="
        searchResultUrl="https://www.qa4.ezconsult.com/search/results?query="
        onlineOffersUrl="https://www.qa4.ezconsult.com/search/onlineoffers"
        tfBrowsePage="https://www.qa4.ezconsult.com/search/browse/category"
        seBrowsePage="https://www.qa4.ezconsult.com/search/se/contract-lab"
        customGroupUrl="https://www.qa4.ezconsult.com/search/browse/results?customGroup="
    }
    qa5 {
        home = "http://www.qa5.ezconsult.com/"
        seSrpUrl = "https://www.qa5.ezconsult.com/search/se/results?keyword="
        searchResultUrl="https://www.dev.ezconsult.com/search/results?query="
        onlineOffersUrl="https://www.qa5.ezconsult.com/search/onlineoffers"
        tfBrowsePage="https://www.qa5.ezconsult.com/search/browse/category"
        seBrowsePage="https://www.qa5.ezconsult.com/search/se/contract-lab"
        customGroupUrl="https://www.qa5.ezconsult.com/search/browse/results?customGroup="
    }
    prod {
        home = "http://www.ezconsult.com/"
        ezrxhome="https://ezrx.com/"
        seSrpUrl = "http://www.ezconsult.com/search/se/results?keyword="
        searchResultUrl="http://www.ezconsult.com/search/results?query="
        onlineOffersUrl="http://www.ezconsult.com/search/onlineoffers"
        tfBrowsePage="http://www.ezconsult.com/search/browse/category"
        seBrowsePage="http://www.ezconsult.com/search/se/contract-lab"
        customGroupUrl="http://www.ezconsult.com/search/browse/results?customGroup="
        ampliseq="https://ampliseq.com/"
        cnhome="http://www.ezconsult.cn"
    }
    uat {

        ezrxhome="https://uat.ezrx.com/"
            }
}