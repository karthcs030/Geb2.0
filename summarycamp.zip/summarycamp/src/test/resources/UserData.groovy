environments {
    US {
        //B2C - My Profile validation
        username_partial = "tfaccountstestuser_us_002@ezconsult.com"
        username_pending = "tfaccountstestuser_us_003@ezconsult.com"
        username_full = "tfaccountstestuser_us_full@ezconsult.com"

        REGISTER_USER {
            partial = ""
            full = "testuser034@test.com"
        }

        CRM {
            username_crm = "testusercrm"

            // Approve requests
            request_full = "testuser025@test.com"
            request_address = "tfaccountstestuser_us_full@ezconsult.com"

            user_list_partial_user = "tfaccountstestuser_us_002@ezconsult.com"
            user_list_pending_user = "tfaccountstestuser_us_003@ezconsult.com"
            user_list_full_user = "pttest20200907223005@pt.com"
        }

        company = "ABC Company"
        job_title = "Scientist"
        department = "Research"
        building = "123"
        street = "13112 EVENING CREEK DR S"
        city = "SAN DIEGO"
        state = "CA"
        state_name = "California"
        country = "United States"
        zip = "92128"
        phone = "1234567890"
        fax = "12345"
        billing_address_same = "Yes"
        password = "Password@123"
        newpassword = "Newpassword@123"

    }

    JP {
        username_partial = "tfaccountstest_jp_partial@ezconsult.com"
        username_pending = "tfaccountstest_jp_pending@ezconsult.com"
        username_full = "tfaccountstest_jp_full@ezconsult.com"

        REGISTER_USER {
            partial = ""
            full = "testuser034@test.com"
        }
        company = "ABC Company"
        job_title = "Scientist"
        department = "Research"
        building = "123"
        street = "Street name"
        city = "City name"
        state = "Hokkaido"
        Prefectures = "Hokkaido"
        country = "Japan"
        zip = "092-0215"
        phone = "1234567890"
        fax = "12345"
        billing_address_same = "Yes"
        password = "Password@123"
        newpassword = "Newpassword@123"
    }

    CN {
        username_partial = "tfaccountstest_cn_partial@ezconsult.com"
        username_pending = "tfaccountstest_cn_pending@ezconsult.com"
        username_full = "tfaccountstest_cn_full@ezconsult.com"
//        username_partial = "testuser017@test.com"
//        username_pending = "testuser021@test.com"
        company = "ABC Company"
        job_title = "Scientist"
        department = "Research"
        building = "123"
        street = "Street name"
        city = "City name"
        state = "Beijing"
        country = "China"
        zip = "100006"
        phone = "1234567890"
        fax = "12345"
        billing_address_same = "Yes"
        password = "Password@123"
        newpassword = "Newpassword@123"

    }

    TH {
        username_partial = "tfaccountstest_th_partial@ezconsult.com"
        username_pending = "tfaccountstestuser_th_pending@ezconsult.com"
        username_dealer = "tfaccountstestuser_th_dealer@ezconsult.com"
        company = "ABC Company"
        job_title = "Scientist"
        department = "Research"
        building = "123"
        street = "Street name"
        city = "City name"
        state = "Buriram"
        country = "Thailand"
        zip = "31000"
        phone = "1234567890"
        fax = "12345"
        billing_address_same = "Yes"
        password = "Password@123"
        newpassword = "Newpassword@123"

    }

    IL {
        username_partial = "tfaccountstest_il_partial@ezconsult.com"
        username_pending = "tfaccountstestuser_il_pending@ezconsult.com"
        username_dealer = "tfaccountstestuser_il_dealer@ezconsult.com"
        company = "ABC Company"
        job_title = "Scientist"
        department = "Research"
        building = "123"
        street = "Street name"
        city = "City name"
        state = "Jerusalem"
        country = "Israel"
        zip = "9103401"
        phone = "1234567890"
        fax = "12345"
        billing_address_same = "Yes"
        password = "Password@123"
        newpassword = "Newpassword@123"

    }
}